from setuptools import setup

setup(
    name='attengineshell',
    version='0.1',
    description='This is the attribute engine',
    url='http://attribute-engine',
    packages=['attengineshell','attengineshell.attributes'],
    install_requires=[
        'numpy==1.16.4',
    ],
    python_requires='>=3',
    test_suite='nose.collector',
    tests_require=['nose'],
    scripts=['bin/entry-1'],
    entry_points={
        'console_scripts': ['entry-2=attengineshell.command_line:main'],
    },
    # setup_requires=["pytest-runner", ...],
    # tests_require=["pytest", ...],
    zip_safe=False)
