from distributed import Scheduler
from dask.distributed import Client, progress
# from distributed.bokeh.scheduler import BokehScheduler
from distributed.dashboard import BokehScheduler
import shlex, subprocess
import os


class DASKScheduler:
    def __init__(self, ipaddr, scheduler_port=8786, boken_port=8787, workers=None):
        if workers is None:
            self.workers = []
        else:
            self.workers = workers

        temp = os.popen('which python').read()
        basebin = os.path.dirname(temp)

        self.scheduler_command = basebin + '/dask-scheduler'  # '/glb/data/cdis_projects/users/ussnis/miniconda3/envs/pvenv/bin/dask-scheduler'
        self.worker_command = basebin + '/dask-worker'  # ''/glb/data/cdis_projects/users/ussnis/miniconda3/envs/pvenv/bin/dask-worker'
        self.scheduler_port = scheduler_port
        self.boken_port = boken_port
        self.ipaddress = ipaddr
        self.scheduler_address = 'tcp://{0}:{1}'.format(self.ipaddress, self.scheduler_port)

    def start(self):
        cmd = "{0} --host {1} --port {2} --dashboard-address :{3}".format(self.scheduler_command, self.ipaddress, self.scheduler_port, self.boken_port)
        args = shlex.split(cmd)
        self.scheduler_log = open('sch.log', 'w')
        self.scheduler_proc = subprocess.Popen(args, stdout=self.scheduler_log, stderr=self.scheduler_log)

        print("Starting Scheduler")

    def start_workers(self):
        self.worker_log = open('worker.log', 'w')
        for worker in self.workers:
            if worker.startswith('#'):
                continue
            cmd = "ssh " + worker + " 'source /etc/profile; source scripts/loadve.sh;" + \
                  "export MKL_NUM_THREADS = 1; " + \
                  "export NUMEXPR_NUM_THREADS = 1; " + \
                  "export OMP_NUM_THREADS = 1; " + \
                  self.worker_command + " " + self.scheduler_address + " --local-directory ~/.dask_worker_space --nprocs=15;'"
            args = shlex.split(cmd)
            proc = subprocess.Popen(args, stdout=self.worker_log, stderr=self.worker_log)
            # proc = subprocess.call(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True)
            print('starting ' + cmd)

        print('Started worker!')

    def stop_workers(self):

        print("Stopping Worker")
        for worker in self.workers:
            cmd = "ssh " + worker + " 'killall dask-worker'"
            args = shlex.split(cmd)
            proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True)

    def get_client(self):
        return Client(self.scheduler_address)

    def get_boken(self):
        return 'http://{0}:{1}/status'.format(self.ipaddress, self.boken_port)

    def get_sch(self):
        return self.scheduler

    def stop_scheduler(self):
        print("Stopping Scheduler")
        self.stop_workers()
        self.scheduler_proc.kill()

    def __del__(self):
        print('Cleaning attribute engine')
        self.stop_scheduler()

