from unittest import TestCase

import attengineshell


class TestJoke(TestCase):

    def test_is_string(self):
        s = attengineshell.joke()
        self.assertTrue(isinstance(s, str))
