

# base class for attribute engine computing
class ComputeBase(object):
    original_vt = ''

    # constructor
    def __init__(self, in_vt, output_path, attributes, configfile='compute.yaml', parameters=None):
        pass

    # start the engine
    def start(self, **kwargs):
        pass

