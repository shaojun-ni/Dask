from . import AttributeBase
import numpy as np
from . import utils
import zarr


# this class implements the envelope attribute
class Instantaneous(AttributeBase.AttributeBase):
    # constructor
    def __init__(self, in_file, out_file, use_compressor=False):
        super(Instantaneous, self).__init__(in_file, out_file, True, use_compressor)

    # get parameter
    @staticmethod
    def get_parameters():
        return ""

    # get overlap depth
    def _get_depth(self):
        return {0: 0, 1: 0, 2: 12}

    # compute envelope attribute
    def _map_func(self, chunkdata):
        return np.rad2deg(np.angle(utils.hilbert(chunkdata), 0))

    # adjust chunk size
    def _check_chunksize_by_file(self):
        z_f = zarr.open(self.in_file, mode='r')
        z = self._check_depth(z_f.shape[2], z_f.chunks[2], 12)
        if z != z_f.chunks[2]:
            return z_f.chunks[0], z_f.chunks[1], z
        else:
            return None
