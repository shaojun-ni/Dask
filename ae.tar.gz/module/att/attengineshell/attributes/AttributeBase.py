import os
import zarr
import dask.array as da
import math


# base class for attribute
class AttributeBase(object):
    # constructor
    def __init__(self, in_file, out_file, overlap=True, use_compressor_output=True):
        self.in_file = in_file
        self.output_path = out_file
        self.overlap = overlap
        self.use_compressor_output = use_compressor_output
        self.validated = True

    # set parameter
    def set_parameters(self, parameters=None):
        pass

    # start computing the attribute
    def run(self, client):
        if not self.validated:
            print("Can't run, parameters were not validated")
            return

        # load data into memory
        if not isinstance(self.in_file, da.core.Array):
            chunk_size = None
            if self.overlap:
                chunk_size = self._check_chunksize_by_file()
            if chunk_size is None:
                chunkdata = da.from_zarr(self.in_file)
            else:
                chunkdata = da.from_zarr(self.in_file, chunks=chunk_size)

            chunkdata = client.persist(chunkdata)
        else:
            chunkdata = self.in_file

        if self.overlap:
            return self._compute_with_overlap(chunkdata, client)
        else:
            return self._compute_without_overlap(chunkdata, client)

    # compute the attribute with overlap
    def _compute_with_overlap(self, chunkdata, client):
        depth = self._get_depth()
        boundary = self._get_boundary()
        daskout = da.map_overlap(chunkdata, self._map_func, depth=depth, boundary=boundary, trim=True, dtype=chunkdata.dtype)
        daskout = client.persist(daskout)

        self._save_output(daskout)

        return chunkdata, daskout

    # compute the attribute without overlap
    def _compute_without_overlap(self, chunkdata, client):
        daskout = da.map_blocks(self._map_func, chunkdata, dtype=chunkdata.dtype)
        daskout = client.persist(daskout)

        self._save_output(daskout)

        return chunkdata, daskout

    # the actual function to do the compute
    def _map_func(self, chunkdata):
        raise NotImplementedError()

    # save the compute result to the zarr file.
    def _save_output(self, daskout):
        print(self.output_path)
        if os.path.isdir(os.path.dirname(self.output_path)):
            print("output_path", self.output_path)
            daskout.to_zarr(self.output_path, compressor=None)
        else:
            print('Invalid output zarr path')

    # check the chunksize whether is ok for for the, it has to be override when overlap is True
    def _check_chunksize_by_file(self):
        raise NotImplementedError()

    # check the chunk length is bigger than the depth required
    def _check_depth(self, length, chunk_len, depth):
        r = length % chunk_len
        n = math.ceil(length / chunk_len)
        c = chunk_len
        if r < depth:
            c = math.ceil((length + depth * n) / n)
        r = length % c
        if r < depth:
            raise SystemExit()

        return c

    # get depth, it has to be override when overlap is True
    def _get_depth(self) -> tuple:
        pass

    # get boundary
    def _get_boundary(self):
        return 'reflect'
