from . import AttributeBase
import zarr
import dask.array as da
import voice.voice_wrap as vw
import logging as log
import numpy as np
import matplotlib.pyplot as plt

# this class implements the complex trace attribute
class VoiceComplexTrace(AttributeBase.AttributeBase):
    # constructor
    def __init__(self, in_file, out_file, attribute_name, use_compressor=False):
        super(VoiceComplexTrace, self).__init__(in_file, out_file, True, use_compressor)
        self.validated = True
        self.attribute_name = attribute_name
        self.length = 27

    # get parameter
    @staticmethod
    def get_parameters():
        return "attribute_name:string, length:int"

    # set parameter
    def set_parameters(self, parameters=None):
        if parameters is not None:
            if "length" in parameters:
                self.length = int(parameters["length"])
            if "attribute_name" in parameters:
                self.attribute_name = int(parameters["attribute_name"])

        log.info('set param {0}'.format('in_file'))

    # get overlap depth
    def _get_depth(self):
        return {0: 0, 1: 0, 2: self.length}

    # get boundary for overlap
    def _get_boundary(self):
        return {0: 0, 1: 0, 2: 0}

    def _compute_with_overlap(self, chunkdata, client):
        depth = self._get_depth()

        boundary = self._get_boundary()
        print("chundata size is: ", chunkdata.shape)
        daskout = da.map_overlap(chunkdata, self._voice_complex_trace, depth=depth, boundary=boundary, trim=True,
                                 dtype=chunkdata.dtype,
                                 length=self.length)
        daskout = client.persist(daskout)

        print("output daskout size is: ", daskout.shape)

        self._save_output(daskout)

        return chunkdata, daskout

    # adjust chunk size
    def _check_chunksize_by_file(self):
        z_f = zarr.open(self.in_file, mode='r')
        z = self._check_depth(z_f.shape[2], z_f.chunks[2], self.length)
        y = self._check_depth(z_f.shape[1], z_f.chunks[1], 2)

        if z != z_f.chunks[2] or y != z_f.chunks[1]:
            return z_f.chunks[0], y, z
        else:
            return None

    def _voice_complex_trace(self, input_data, length):
        size_x = input_data.shape[0]
        size_y = input_data.shape[1]
        size_z = input_data.shape[2]

        # if size_x != 0:
        #     np.save('/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismicCube.npy', input_data)

        output_data = vw.complex_trace_run(self.attribute_name, input_data, size_x, size_y, size_z, length)

        return np.reshape(output_data, (size_x, size_y, size_z))

