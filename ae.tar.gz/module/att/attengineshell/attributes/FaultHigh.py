from abc import ABC

from . import AttributeBase
import zarr
import dask.array as da
import voice.voice_wrap as vw
import logging as log
import numpy as np

# this class implements the semblance attribute
class FaultHigh(AttributeBase.AttributeBase):
    # constructor
    def __init__(self, in_file, out_file, data_order='H', use_compressor=False):
        super(FaultHigh, self).__init__(in_file, out_file, True, use_compressor)
        self.local_scale = 2
        self.structure_scale = 10
        self.vertical_stretch = 2
        self.data_order = data_order

    # get parameter
    @staticmethod
    def get_parameters():
        return "local_scale:int,structure_scale:int,vertical_stretch:int"

    # set parameter
    def set_parameters(self, parameters=None):
        self.validated = True
        if parameters is not None:
            if "local_scale" in parameters:
                self.local_scale = int(parameters["local_scale"])
            if "structure_scale" in parameters:
                self.structure_scale = int(parameters["structure_scale"])
            if "vertical_stretch" in parameters:
                self.vertical_stretch = int(parameters["vertical_stretch"])

        log.info('set param {0}'.format('in_file'))

    # compute semblance attribute. since we call semblance which is imported, we have to override this method.
    def _compute_with_overlap(self, chunkdata, client):
        depth = self._get_depth()
        boundary = self._get_boundary()
        print("chundata size is: ", chunkdata.shape)
        daskout = da.map_overlap(chunkdata, self._fault_high, depth=depth, boundary=boundary, trim=True,
                dtype=chunkdata.dtype,
                local_scale=self.local_scale, structure_scale=self.structure_scale, vertical_stretch=self.vertical_stretch)
        daskout = client.persist(daskout)

        self._save_output(daskout)

        return chunkdata, daskout

    # check the chunksize whether it is fit for overlap
    def _check_chunksize_by_file(self):
        z_f = zarr.open(self.in_file, mode='r')
        x = self._check_depth(z_f.shape[0], z_f.chunks[0], 0)
        y = self._check_depth(z_f.shape[1], z_f.chunks[1], 0)
        z = self._check_depth(z_f.shape[2], z_f.chunks[2], 10)
        if x != z_f.chunks[0] or y != z_f.chunks[1] or z != z_f.chunks[2]:
            return x, y, z
        else:
            return None

    # get overlap depth
    def _get_depth(self):
        return {0: 0, 1: 0, 2: 10}

    # get boundary for overlap
    def _get_boundary(self):
        return {0: 0, 1: 0, 2: 0}

    def _fault_high(self, input_data, local_scale, structure_scale, vertical_stretch):
        size_x = input_data.shape[0]
        size_y = input_data.shape[1]
        size_z = input_data.shape[2]

        output_data = vw.fault_high_run(input_data, size_x, size_y, size_z, local_scale, structure_scale, vertical_stretch)
        return np.reshape(output_data, (size_x, size_y, size_z))
