
import numpy as np

def hilbert(in_data):
    N = in_data.shape[-1]

    Xf = np.fft.fftpack.fft(in_data, n=N, axis=-1)

    h = np.zeros(N)
    if N % 2 == 0:
        h[0] = h[N // 2] = 1
        h[1:N // 2] = 2
    else:
        h[0] = 1
        h[1:(N + 1) // 2] = 2

    if in_data.ndim > 1:
        ind = [np.newaxis] * in_data.ndim
        ind[-1] = slice(None)
        h = h[ind]
    x = np.fft.fftpack.ifft(Xf * h, axis=-1)
    return x