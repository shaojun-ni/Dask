from . import AttributeBase
import zarr
import dask.array as da
import voice.voice_wrap as vw
import logging as log
import numpy as np


# this class implements Semblance attribute
class SharpSemblance(AttributeBase.AttributeBase):
    # constructor
    def __init__(self, in_file, out_file, use_compressor=False):
        super(SharpSemblance, self).__init__(in_file, out_file, True, use_compressor)
        self.validated = True
        self.win_x = 3
        self.win_y = 3
        self.win_z = 11

    # set parameter
    def set_parameters(self, parameters=None):
        if parameters is not None:
            if "win_x" in parameters:
                self.win_x = int(parameters["win_x"])
            if "win_y" in parameters:
                self.win_y = int(parameters["win_y"])
            if "win_z" in parameters:
                self.win_z = int(parameters["win_z"])

        log.info('set param {0}'.format('in_file'))

    # get parameter
    @staticmethod
    def get_parameters():
        return "win_x:int,win_y:int,win_z:int"

    # compute semblance attribute. since we call semblance which is imported, we have to override this method.
    def _compute_with_overlap(self, chunkdata, client):
        depth = self._get_depth()
        boundary = self._get_boundary()
        print("chundata size is: ", chunkdata.shape)
        daskout = da.map_overlap(chunkdata, self._sharpsemblance, depth=depth, boundary=boundary, trim=True,
                                 dtype=chunkdata.dtype,
                                 win_x=self.win_x, win_y=self.win_y, win_z=self.win_z)
        daskout = client.persist(daskout)

        self._save_output(daskout)

        return chunkdata, daskout

    # check the chunksize whether it is fit for overlap
    def _check_chunksize_by_file(self):
        z_f = zarr.open(self.in_file, mode='r')
        x = self._check_depth(z_f.shape[0], z_f.chunks[0], self.win_x)
        y = self._check_depth(z_f.shape[1], z_f.chunks[1], self.win_y)
        z = self._check_depth(z_f.shape[2], z_f.chunks[2], self.win_y)
        if x != z_f.chunks[0] or y != z_f.chunks[1] or z != z_f.chunks[2]:
            return x, y, z
        else:
            return None

    # get overlap depth
    def _get_depth(self):
        return {0: self.win_x, 1: self.win_y, 2: self.win_z}

    # get boundary for overlap
    def _get_boundary(self):
        return {0: 0, 1: 0, 2: 0}

    def _sharpsemblance(self, input_data, win_x, win_y, win_z):
        #print("chunk data size is: ", input_data.shape)

        # print("input length:")
        # print(input_data.shape(0))
        # print("print input data ...")
        # if (input_data.shape(0)) > 50:
        #     for i in range(50):
        #         print(input_data[i])

        size_x = input_data.shape[0]
        size_y = input_data.shape[1]
        size_z = input_data.shape[2]

        output_data = vw.sharp_semblance_run(input_data, size_x, size_y, size_z, win_x, win_y, win_z)
        return np.reshape(output_data, (size_x, size_y, size_z))
