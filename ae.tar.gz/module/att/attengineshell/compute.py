import os
import sys
import yaml
import shutil
from dask.distributed import Client
from dask_jobqueue import LSFCluster
import dask.array as da
from . import ComputeBase
from . import FileConverter
from . import AttributeType
from .attributes import Instantaneous
from .attributes import SharpSemblance
from .attributes import Semblance
from .attributes import Envelope
from .attributes import VoiceComplexTrace
from .attributes import VoiceSemblance
from .attributes import FaultHigh
import re
import importlib as imp
import inspect
import gc
import time
from multiprocessing import Process, Queue


def setup_hpc_nodes_proc(hpc_queue, hpc_project, hpc_time, hpc_core, hpc_processes_per_node, hpc_memory,
                         dask_dashboard_port, hpc_number_of_nodes, use_gpu, queue):
    print("HPC project name is:" + hpc_project)
    job_extra_setting = []
    if use_gpu:
        job_extra_setting = ['-gpu "num=1"']
    cluster = LSFCluster(queue=hpc_queue, project=hpc_project, walltime='{0}:00'.format(hpc_time),
                         cores=hpc_core, processes=hpc_processes_per_node, local_directory='dask-worker-space',
                         memory='{0}GB'.format(hpc_memory), job_extra=job_extra_setting, log_directory='scheduler_log',
                         dashboard_address=':{0}'.format(dask_dashboard_port))
    cluster.scale(hpc_number_of_nodes * hpc_processes_per_node)
    print(cluster.scheduler_address)
    queue.put(cluster.scheduler_address)
    msg = queue.get()
    print(msg)
    cluster.close()


# this class implements the functions to compute attributes
class Compute(ComputeBase):
    split_vt_file = False
    size_x = 300
    size_y = 300
    size_z = 300
    number_of_files = 10
    overlap = 10
    zarr_path = ''
    custom_attrs = list()
    custom_attr_dir = ""
    hpc_processes_per_node = 24
    hpc_number_of_nodes = 5
    dask_dashboard_port = 8790
    hpc_memory = 200
    hpc_time = 80
    hpc_queue = 'default.q'
    hpc_project = 'att_eng'
    hpc_core = 24

    def __init__(self, in_vt, output_path, attributes, configfile='compute.yaml', parameters=None):
        super(Compute, self).__init__(in_vt, output_path, attributes, configfile, parameters)
        self.original_vt = in_vt
        self.client = None
        if attributes.find(',') != -1 or attributes.find(' ') != -1:
            if output_path.endswith('.vt'):
                raise ValueError('When output vt is specified, only one attribute can specify.')

        if 'SharpSemblance' in attributes or \
                'VoiceSemblance' in attributes or \
                'VoiceEnvelope' in attributes or \
                'VoiceFrequency' in attributes or \
                'VoicePhase' in attributes or \
                'VoiceCosPhase' in attributes:
            self.data_type = 'byte'
        else:
            self.data_type = 'float'

        with open(configfile) as f:
            data = yaml.load(f, Loader=yaml.FullLoader)
            self.number_of_files = int(data['number_of_files'])
            self.overlap = int(data['overlap'])
            self.size_x = int(data['size_x'])
            self.size_y = int(data['size_y'])
            self.size_z = int(data['size_z'])
            # self.scheduler_addr = data['scheduler']
            if 'use_compressor' not in data:
                self.use_compressor = False
            if data['use_compressor'] == 'True':
                self.use_compressor = True
            else:
                self.use_compressor = False
            self.max_amplify = int(data.get('max_value_amplify', '5'))
            self.custom_attr_dir = data['custom_attr_dir']
            self.hpc_number_of_nodes = int(data['hpc_NumberOfNodes'])
            self.hpc_processes_per_node = int(data['hpc_NumberOfProcessPerNode'])
            self.hpc_queue = data['hpc_queue']
            self.hpc_memory = int(data['hpc_memory'])
            self.hpc_project = data['hpc_project']
            self.hpc_time = data['hpc_time']
            self.hpc_core = data['hpc_NumberOfCore']
            self.dask_dashboard_port = int(data['DASK_dashboard_port'])
            self.parallel_read = data['parallel_read']

        print('max value amplify:{0}'.format(self.max_amplify))
        self.min_value = {}
        self.max_value = {}
        self.original_vt = in_vt

        self.__set_attributes(attributes)
        self.split_vt = False
        self.parameters = parameters
        if self.parameters is not None:
            print('Parameters are {0}'.format(self.parameters))
        else:
            print('Parameter is none.')
        self.__init_path(output_path)
        print('compute attribute:{0}'.format(self.attributes))
        print('Use compressor for zarr:{0}'.format(self.use_compressor))

    def __init_path(self, output_path):
        self.final_output_path = None
        if output_path.endswith('.vt'):
            self.final_output_path = output_path
            self.output_path = os.path.dirname(output_path)
        else:
            self.output_path = output_path

        self.zarr_path = '{0}/data_zarr'.format(self.output_path)
        if not os.path.exists(self.zarr_path):
            os.mkdir(self.zarr_path)
        filepath = os.path.basename(self.original_vt)
        self.name = os.path.splitext(filepath)[0]
        self.real_zarr_path = '{0}/{1}'.format(self.zarr_path, self.name)
        self.zarr_out_path = '{0}/out/{1}'.format(self.zarr_path, self.name)
        if not os.path.exists(self.zarr_out_path):
            os.makedirs(self.zarr_out_path)

    def __set_attributes(self, attributes):
        print(attributes)
        parts = attributes.split(',')
        self.attributes = AttributeType.Non
        for attr in parts:
            if attr.strip() == 'Semblance':
                self.attributes |= AttributeType.Semblance
            elif attr.strip() == 'VoiceSemblance':
                self.attributes |= AttributeType.VSemblance
            elif attr.strip() == 'Envelope':
                self.attributes |= AttributeType.Envelope
            elif attr.strip() == 'VoiceEnvelope':
                self.attributes |= AttributeType.VEnvelope
            elif attr.strip() == 'VoiceFrequency':
                self.attributes |= AttributeType.VFrequency
            elif attr.strip() == 'VoicePhase':
                self.attributes |= AttributeType.VPhase
            elif attr.strip() == 'VoiceCosPhase':
                self.attributes |= AttributeType.VCosPhase
            elif attr.strip() == 'Instantaneous':
                self.attributes |= AttributeType.Instantaneous
            elif attr.strip() == 'SharpSemblance':
                self.attributes |= AttributeType.SharpSemblance
            elif attr.strip() == 'FaultHigh':
                self.attributes |= AttributeType.FaultHigh
            else:
                self.attributes |= AttributeType.Custom
                self.custom_attrs.append(attr.strip())

    def __clean_zarr_out_path(self, attribute):
        tmp = '{0}/{1}'.format(self.zarr_out_path, attribute.lower())
        if not os.path.exists(tmp):
            os.mkdir(tmp)
        else:
            shutil.rmtree(tmp)
            os.mkdir(tmp)
        return tmp

    def calculate_min_max(self, array, attribute_type):
        t_max = da.max(array).compute() * self.max_amplify
        t_min = -t_max

        c_min = self.min_value.get(attribute_type)
        c_max = self.max_value.get(attribute_type)
        if c_min is None:
            self.min_value[attribute_type] = t_min
        elif c_min > t_min:
            self.min_value[attribute_type] = t_min

        if c_max is None:
            self.max_value[attribute_type] = t_max
        elif c_max < t_max:
            self.max_value[attribute_type] = t_max

        print('{0} max value is {1}'.format(attribute_type, self.max_value[attribute_type]))
        print('{0} min value is {1}'.format(attribute_type, self.min_value[attribute_type]))

    def get_zarr_output_file_path(self, subname, attribute_name, clean_out=True):
        if clean_out:
            self.__clean_zarr_out_path(attribute_name)

        return '{0}/{2}/{1}_{2}.zarr'.format(self.zarr_out_path, subname, attribute_name.lower())

    def computing(self, filename, subname, clean_output=True):
        data_in = None
        if (self.attributes & AttributeType.Semblance) == AttributeType.Semblance:
            # semblance
            semblance_out_file_zarr = self.get_zarr_output_file_path(subname, AttributeType.Semblance.name,
                                                                     clean_output)
            print('semblance_out_file_zarr:' + semblance_out_file_zarr)
            param = None
            if self.parameters is not None:
                if "Semblance" in self.parameters:
                    param = self.parameters["Semblance"]
            semblance = Semblance(filename, semblance_out_file_zarr, self.use_compressor)
            semblance.set_parameters(param)
            data_in, res_semblance = semblance.run(self.client)
            self.calculate_min_max(res_semblance, AttributeType.Semblance.name)

            del res_semblance

        if (self.attributes & AttributeType.SharpSemblance) == AttributeType.SharpSemblance:
            # sharpsemblance
            sharpsemblance_out_file_zarr = self.get_zarr_output_file_path(subname, AttributeType.SharpSemblance.name,
                                                                          clean_output)
            print('Sharpsemblance_out_file_zarr:' + sharpsemblance_out_file_zarr)
            param = None
            if self.parameters is not None:
                if "SharpSemblance" in self.parameters:
                    param = self.parameters["SharpSemblance"]
            sharpsemblance = SharpSemblance(filename, sharpsemblance_out_file_zarr, self.use_compressor)
            sharpsemblance.set_parameters(param)
            data_in, res_sharpsemblance = sharpsemblance.run(self.client)
            self.min_value[AttributeType.SharpSemblance.name] = 0.0
            self.max_value[AttributeType.SharpSemblance.name] = 1.0

            del res_sharpsemblance

        if (self.attributes & AttributeType.VSemblance) == AttributeType.VSemblance:
            # VoiceSemblance
            voice_semblance_out_file_zarr = self.get_zarr_output_file_path(subname, AttributeType.VSemblance.name,
                                                                           clean_output)
            print('VSemblance_out_file_zarr:' + voice_semblance_out_file_zarr)
            param = None
            if self.parameters is not None:
                if "VoiceSemblance" in self.parameters:
                    param = self.parameters["VoiceSemblance"]
            voice_semblance = VoiceSemblance(filename, voice_semblance_out_file_zarr, self.use_compressor)
            voice_semblance.set_parameters(param)
            data_in, res_voice_semblance = voice_semblance.run(self.client)
            self.min_value[AttributeType.VSemblance.name] = 0.0
            self.max_value[AttributeType.VSemblance.name] = 1.0

            del res_voice_semblance

        if (self.attributes & AttributeType.VEnvelope) == AttributeType.VEnvelope:
            # VoiceEnvelope
            VoiceEnvelope_out_file_zarr = self.get_zarr_output_file_path(subname, AttributeType.VEnvelope.name,
                                                                         clean_output)
            print('VoiceEnvelope_out_file_zarr:' + VoiceEnvelope_out_file_zarr)
            param = None
            if self.parameters is not None:
                if "VoiceEnvelope" in self.parameters:
                    param = self.parameters["VoiceEnvelope"]
                    print("param is:", param)
            complex_trace = VoiceComplexTrace(filename, VoiceEnvelope_out_file_zarr, 'ENVELOPE', self.use_compressor)
            complex_trace.set_parameters(param)
            data_in, res_ComplexTrace = complex_trace.run(self.client)
            self.min_value[AttributeType.VEnvelope.name] = 0.0
            self.max_value[AttributeType.VEnvelope.name] = 255.0

            del res_ComplexTrace

        if (self.attributes & AttributeType.VFrequency) == AttributeType.VFrequency:
            # VoiceFrequency
            VoiceFrequency_out_file_zarr = self.get_zarr_output_file_path(subname, AttributeType.VFrequency.name,
                                                                          clean_output)
            print('VoiceFrequency_out_file_zarr:' + VoiceFrequency_out_file_zarr)
            param = None
            if self.parameters is not None:
                if "VoiceFrequency" in self.parameters:
                    param = self.parameters["VoiceFrequency"]
                    print("param is:", param)
            complex_trace = VoiceComplexTrace(filename, VoiceFrequency_out_file_zarr, 'FREQUENCY', self.use_compressor)
            complex_trace.set_parameters(param)
            data_in, res_ComplexTrace = complex_trace.run(self.client)
            self.min_value[AttributeType.VFrequency.name] = -1.0
            self.max_value[AttributeType.VFrequency.name] = 1.0

            del res_ComplexTrace

        if (self.attributes & AttributeType.VPhase) == AttributeType.VPhase:
            # VoicePhase
            VoicePhase_out_file_zarr = self.get_zarr_output_file_path(subname, AttributeType.VPhase.name, clean_output)
            print('VoicePhase_out_file_zarr:' + VoicePhase_out_file_zarr)
            param = None
            if self.parameters is not None:
                if "VoicePhase" in self.parameters:
                    param = self.parameters["VoicePhase"]
                    print("param is:", param)
            complex_trace = VoiceComplexTrace(filename, VoicePhase_out_file_zarr, 'PHASE', self.use_compressor)
            complex_trace.set_parameters(param)
            data_in, res_ComplexTrace = complex_trace.run(self.client)
            self.min_value[AttributeType.VPhase.name] = -180.0
            self.max_value[AttributeType.VPhase.name] = 180.0

            del res_ComplexTrace

        if (self.attributes & AttributeType.VCosPhase) == AttributeType.VCosPhase:
            # VoiceCosPhase
            VoiceCosPhase_out_file_zarr = self.get_zarr_output_file_path(subname, AttributeType.VCosPhase.name,
                                                                         clean_output)
            print('VoiceCosPhase_out_file_zarr:' + VoiceCosPhase_out_file_zarr)
            param = None
            if self.parameters is not None:
                if "VoiceCosPhase" in self.parameters:
                    param = self.parameters["VoiceCosPhase"]
                    print("param is:", param)
            complex_trace = VoiceComplexTrace(filename, VoiceCosPhase_out_file_zarr, 'COSINE_PHASE',
                                              self.use_compressor)
            complex_trace.set_parameters(param)
            data_in, res_ComplexTrace = complex_trace.run(self.client)
            self.min_value[AttributeType.VCosPhase.name] = 0.0
            self.max_value[AttributeType.VCosPhase.name] = 1.0

            del res_ComplexTrace

        if (self.attributes & AttributeType.FaultHigh) == AttributeType.FaultHigh:
            # FaultHigh
            FaultHigh_out_file_zarr = self.get_zarr_output_file_path(subname, AttributeType.FaultHigh.name,
                                                                         clean_output)
            print('FaultHigh_out_file_zarr:' + FaultHigh_out_file_zarr)
            param = None
            if self.parameters is not None:
                if "FaultHigh" in self.parameters:
                    param = self.parameters["FaultHigh"]
                    print("param is:", param)
            fault_high = FaultHigh(filename, FaultHigh_out_file_zarr, 'FAULT_HIGH',
                                              self.use_compressor)
            fault_high.set_parameters(param)
            data_in, res_FaultHigh = fault_high.run(self.client)
            self.min_value[AttributeType.FaultHigh.name] = 0.0
            self.max_value[AttributeType.FaultHigh.name] = 1.0

            del res_FaultHigh

        if (self.attributes & AttributeType.Envelope) == AttributeType.Envelope:
            # envelope
            single_envelope_out_file_zarr = self.get_zarr_output_file_path(subname, AttributeType.Envelope.name,
                                                                           clean_output)
            print('envelope_out_file_zarr:' + single_envelope_out_file_zarr)

            if data_in is None:
                envelope = Envelope(filename, single_envelope_out_file_zarr, self.use_compressor)
            else:
                envelope = Envelope(data_in, single_envelope_out_file_zarr, self.use_compressor)
            envelope.set_parameters()
            data_in, res_env = envelope.run(self.client)
            self.calculate_min_max(res_env, AttributeType.Envelope.name)
            del res_env

        if (self.attributes & AttributeType.Instantaneous) == AttributeType.Instantaneous:
            # instantaneous
            single_instantaneous_out_file_zarr = self.get_zarr_output_file_path(subname,
                                                                                AttributeType.Instantaneous.name,
                                                                                clean_output)
            print('instananeous_out_file_zarr:' + single_instantaneous_out_file_zarr)
            if data_in is None:
                instantaneous = Instantaneous(filename, single_instantaneous_out_file_zarr, self.use_compressor)
            else:
                instantaneous = Instantaneous(data_in, single_instantaneous_out_file_zarr, self.use_compressor)
            instantaneous.set_parameters()
            data_in, res_instan = instantaneous.run(self.client)
            self.calculate_min_max(res_instan, AttributeType.Instantaneous.name)
            del res_instan

        if (self.attributes & AttributeType.Custom) == AttributeType.Custom:
            # handle custom attributes
            data_in = self.compute_custom_attributes(data_in, filename, subname, clean_output)

        if data_in is not None:
            del data_in
            return True
        else:
            return False

    # compute custom attributes
    def compute_custom_attributes(self, data_in, filename, subname, clean_output):
        for attr_name in self.custom_attrs:
            param = None
            if self.parameters is not None:
                if attr_name in self.parameters:
                    param = self.parameters[attr_name]

            data_in = self._compute_custom_attr(attr_name, data_in, filename, subname, param, clean_output)

        return data_in

    # compute custom attribute
    def _compute_custom_attr(self, attr_name, data_in, filename, subname, param, clean_output):
        custom_attr_out_file_zarr = self.get_zarr_output_file_path(subname, attr_name, clean_output)
        print('{0} out_file_zarr:{1}'.format(attr_name, custom_attr_out_file_zarr))
        attr_class = self._load_custom_class(attr_name)
        if attr_class is None:
            print('{0} does not exist.'.format(attr_name))
            return None

        if data_in is None:
            instance = attr_class(filename, custom_attr_out_file_zarr, self.use_compressor)
        else:
            instance = attr_class(data_in, custom_attr_out_file_zarr, self.use_compressor)

        if param is not None:
            instance.set_parameters(param)
        data_in, res = instance.run(self.client)
        self.calculate_min_max(res, attr_name)
        del res

        return data_in

    # load the class by custom attribute name
    def _load_custom_class(self, in_attr_name):
        files = os.listdir(self.custom_attr_dir)
        # print(files)
        custom_attr_files = list(filter(lambda x: "_attribute.py" in x, files))
        module_name = "customattr"
        for f in custom_attr_files:
            full_path = self.custom_attr_dir + '/' + f
            loader = imp.machinery.SourceFileLoader(module_name, full_path)
            m = loader.load_module()
            tmp = [m[0] for m in inspect.getmembers(m, inspect.isclass) if m[1].__name__ == in_attr_name]
            if tmp:
                attr_name = tmp[0]
            else:
                continue
            print(attr_name)
            if attr_name == in_attr_name:
                myclass = getattr(m, attr_name)
                return myclass

        return None

    def computing_multiple(self):
        ret = True
        tt = {}
        for path, dirs, files in os.walk(self.real_zarr_path, topdown=False):
            # sort directory by creation time
            for d in dirs:
                p = self.real_zarr_path + '/' + d
                t = re.findall('\\d+', p)
                tt[int(t[len(t) - 1])] = d
                print(t)

        for k in sorted(tt.keys()):
            print(tt[k])

        for k in sorted(tt.keys()):
            filename = '{0}/{1}'.format(self.real_zarr_path, tt[k])
            fp = os.path.basename(filename)
            subname = os.path.splitext(fp)[0]
            if not self.computing(filename, subname, k == 0):
                ret = False
                break
            else:
                print("Clean memory...")
                gc.collect()
                time.sleep(2)

        return ret

    def _combine_2_vt_proc(self, attribute):
        print('combine {0} zarr files to vt.'.format(attribute))
        if self.final_output_path is not None:
            final_path = self.final_output_path
        else:
            final_path = '{0}/{1}_{2}.vt'.format(self.output_path, self.name, attribute.lower())
        if os.path.exists(final_path):
            os.remove(final_path)

        zarr_dir_path = '{0}/{1}'.format(self.zarr_out_path, attribute.lower())
        proc = Process(target=FileConverter.combine_zarrs_2_vt,
                       args=(zarr_dir_path, self.original_vt, final_path, self.overlap,
                             self.min_value[attribute], self.max_value[attribute]))
        # FileConverter.combine_zarrs_2_vt(zarr_dir_path, self.original_vt, final_path, self.overlap,
        #                                 self.min_value[attribute], self.max_value[attribute])
        proc.start()
        print('Waiting combine zarr 2 vt to finish...')
        proc.join()

    # combine zarr files to a vt
    def _combine_2_vt(self, attribute):
        print('combine {0} zarr files to vt.'.format(attribute))
        if self.final_output_path is not None:
            final_path = self.final_output_path
        else:
            final_path = '{0}/{1}_{2}.vt'.format(self.output_path, self.name, attribute.lower())
        if os.path.exists(final_path):
            os.remove(final_path)

        zarr_dir_path = '{0}/{1}'.format(self.zarr_out_path, attribute.lower())
        FileConverter.combine_zarrs_2_vt(zarr_dir_path, self.original_vt, final_path, self.overlap,
                                         self.min_value[attribute], self.max_value[attribute])

    # combine zarr files to vts by attributes
    def combine_2_vts(self):
        if (self.attributes & AttributeType.Semblance) == AttributeType.Semblance:
            self._combine_2_vt_proc(AttributeType.Semblance.name)

        if (self.attributes & AttributeType.VSemblance) == AttributeType.VSemblance:
            self._combine_2_vt_proc(AttributeType.VSemblance.name)

        if (self.attributes & AttributeType.SharpSemblance) == AttributeType.SharpSemblance:
            self._combine_2_vt_proc(AttributeType.SharpSemblance.name)

        if (self.attributes & AttributeType.VEnvelope) == AttributeType.VEnvelope:
            self._combine_2_vt_proc(AttributeType.VEnvelope.name)

        if (self.attributes & AttributeType.VFrequency) == AttributeType.VFrequency:
            self._combine_2_vt_proc(AttributeType.VFrequency.name)

        if (self.attributes & AttributeType.VPhase) == AttributeType.VPhase:
            self._combine_2_vt_proc(AttributeType.VPhase.name)

        if (self.attributes & AttributeType.VCosPhase) == AttributeType.VCosPhase:
            self._combine_2_vt_proc(AttributeType.VCosPhase.name)

        if (self.attributes & AttributeType.FaultHigh) == AttributeType.FaultHigh:
            self._combine_2_vt_proc(AttributeType.FaultHigh.name)

        if (self.attributes & AttributeType.Envelope) == AttributeType.Envelope:
            self._combine_2_vt_proc(AttributeType.Envelope.name)

        if (self.attributes & AttributeType.Instantaneous) == AttributeType.Instantaneous:
            self._combine_2_vt_proc(AttributeType.Instantaneous.name)

        # convert custom zarr files to vts
        for attr_name in self.custom_attrs:
            self._combine_2_vt_proc(attr_name)

    # convert a zarr file to a vt file.
    def _convert_2_vt(self, attribute):
        if self.final_output_path is not None:
            out_vt_file = self.final_output_path
        else:
            out_vt_file = '{0}/{1}_{2}.vt'.format(self.output_path, self.name, attribute.lower())

        print('Output vt file:' + out_vt_file)
        if os.path.exists(out_vt_file):
            os.remove(out_vt_file)
        out_file_zarr = self.get_zarr_output_file_path(self.name, attribute.lower(), False)
        print('Input file is:' + out_file_zarr)
        FileConverter.zarr_2_vt(zarr_file=out_file_zarr, vt_file=out_vt_file,
                                original_path=self.original_vt, max_amplify=self.max_amplify,
                                max_value=self.max_value[attribute],
                                min_value=self.min_value[attribute])

    # convert a zarr file to a vt file.
    def _convert_2_vt_proc(self, attribute):
        if self.final_output_path is not None:
            out_vt_file = self.final_output_path
        else:
            out_vt_file = '{0}/{1}_{2}.vt'.format(self.output_path, self.name, attribute.lower())

        print('Output vt file:' + out_vt_file)
        if os.path.exists(out_vt_file):
            os.remove(out_vt_file)
        out_file_zarr = self.get_zarr_output_file_path(self.name, attribute.lower(), False)
        print('Input file is:' + out_file_zarr)
        proc = Process(target=FileConverter.zarr_2_vt, args=(out_file_zarr, out_vt_file,
                                                             self.original_vt, self.max_amplify,
                                                             self.max_value[attribute], self.min_value[attribute]))
        proc.start()
        print('Waiting convert zarr to vt to finish.')
        proc.join()
        # FileConverter.zarr_2_vt(zarr_file=out_file_zarr, vt_file=out_vt_file,
        #                        original_path=self.original_vt, max_amplify=self.max_amplify,
        #                        max_value=self.max_value[attribute],
        #                        min_value=self.min_value[attribute])

    # convert zarr files to vts
    def convert_2_vts(self):
        if (self.attributes & AttributeType.Semblance) == AttributeType.Semblance:
            self._convert_2_vt_proc(AttributeType.Semblance.name)

        if (self.attributes & AttributeType.VSemblance) == AttributeType.VSemblance:
            self._convert_2_vt_proc(AttributeType.VSemblance.name)

        if (self.attributes & AttributeType.SharpSemblance) == AttributeType.SharpSemblance:
            self._convert_2_vt_proc(AttributeType.SharpSemblance.name)

        if (self.attributes & AttributeType.VEnvelope) == AttributeType.VEnvelope:
            self._convert_2_vt_proc(AttributeType.VEnvelope.name)

        if (self.attributes & AttributeType.VFrequency) == AttributeType.VFrequency:
            self._convert_2_vt_proc(AttributeType.VFrequency.name)

        if (self.attributes & AttributeType.VPhase) == AttributeType.VPhase:
            self._convert_2_vt_proc(AttributeType.VPhase.name)

        if (self.attributes & AttributeType.VCosPhase) == AttributeType.VCosPhase:
            self._convert_2_vt_proc(AttributeType.VCosPhase.name)

        if (self.attributes & AttributeType.FaultHigh) == AttributeType.FaultHigh:
            self._convert_2_vt_proc(AttributeType.FaultHigh.name)

        if (self.attributes & AttributeType.Envelope) == AttributeType.Envelope:
            self._convert_2_vt_proc(AttributeType.Envelope.name)

        if (self.attributes & AttributeType.Instantaneous) == AttributeType.Instantaneous:
            self._convert_2_vt_proc(AttributeType.Instantaneous.name)

        # convert custom zarr files to vts
        for attr_name in self.custom_attrs:
            self._convert_2_vt_proc(attr_name)

    # create scheduler, and client
    def create_scheduler(self, use_gpu):
        print("HPC project name is:" + self.hpc_project)
        q = Queue()
        p = Process(target=setup_hpc_nodes_proc, args=(self.hpc_queue, self.hpc_project, self.hpc_time, self.hpc_core,
                                                       self.hpc_processes_per_node, self.hpc_memory,
                                                       self.dask_dashboard_port,
                                                       self.hpc_number_of_nodes, use_gpu, q))
        p.start()
        scheduler_address = q.get()
        print(scheduler_address)
        client = Client(scheduler_address, timeout=60)
        return client, q

    def _close_lsf(self, cluster_queue):
        print('Close cluster.')
        self.client.close()
        if cluster_queue is not None:
            cluster_queue.put("LSF Finish!")

    # start the computing
    def start(self, split_vt=False, skip_2_zarr=False, use_hpc=True, use_gpu=False):
        cluster_queue = None
        if use_hpc:
            self.client, cluster_queue = self.create_scheduler(use_gpu)  # self.setup_hpc_nodes(use_gpu)
        else:
            self.client = Client()

        # print("is parallel read", self.parallel_read)
        if not skip_2_zarr:
            if split_vt:
                if self.parallel_read == True:
                    print("going to parallel read")
                    FileConverter.vt_2_zarrs_by_bin_parallel(self.original_vt, self.zarr_path, self.number_of_files,
                                                             self.overlap, self.size_x, self.size_y, self.size_z,
                                                             self.data_type)
                else:
                    FileConverter.vt_2_zarrs_by_bin(self.original_vt, self.zarr_path, self.number_of_files,
                                                    self.overlap, self.size_x, self.size_y, self.size_z, self.data_type)
            else:
                zarr_file = FileConverter.vt_2_zarr(self.original_vt, self.zarr_path, self.size_x, self.size_y,
                                                    self.size_z, self.use_compressor, self.data_type)
        else:
            zarr_file = '{0}/{1}.zarr'.format(self.real_zarr_path, self.name)

        # sys.exit("llong terminate the program.")          #llong test
        if split_vt:
            self.split_vt = True
            if self.computing_multiple():
                self._close_lsf(cluster_queue)
                self.combine_2_vts()
            else:
                print("Computing failed!")
        else:
            self.split_vt = False
            print('computing...input zarr file is ' + zarr_file)
            if self.computing(zarr_file, self.name):
                gc.collect()
                time.sleep(2)
                self._close_lsf(cluster_queue)
                self.convert_2_vts()
            else:
                print("Computing failed!")

        print('Done!')
