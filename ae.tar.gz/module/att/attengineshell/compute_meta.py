import os
import yaml

from . import AttributeType
from . import ComputeMetaDataBase
# from .attributes import Instantaneous
from .attributes import Semblance
# from .attributes import Envelope
import inspect
import importlib as imp


# this class return meta data of the attribute engine, such as supported attributes, and its parameters.
class ComputeMetaData(ComputeMetaDataBase):
    # constructor
    def __init__(self, configfile='compute.yaml'):
        with open(configfile) as f:
            data = yaml.load(f, Loader=yaml.FullLoader)
            self.custom_attr_dir = data['custom_attr_dir']

    # get attribute parameters if it has one
    def get_parameters(self):
        param = {}
        param[AttributeType.Semblance.name] = Semblance.get_parameters()

        # get custom attributes parameters
        files = os.listdir(self.custom_attr_dir)
        custom_attr_files = list(filter(lambda x: "_attribute.py" in x, files))
        # print(custom_attr_files)
        module_name = "customattr"
        for f in custom_attr_files:
            full_path = self.custom_attr_dir + '/' + f
            loader = imp.machinery.SourceFileLoader(module_name, full_path)
            m = loader.load_module()
            for n in inspect.getmembers(m, inspect.isclass):
                attr_name = n[1].__name__
                if attr_name in param.keys():
                    continue
                myclass = getattr(m, attr_name)
                if myclass.get_parameters():
                    param[attr_name] = myclass.get_parameters()

        return param

    # get supported attributes
    def get_attributes(self):
        attrs = [AttributeType.Semblance.name, AttributeType.SharpSemblance.name, AttributeType.Instantaneous.name,
                 AttributeType.Envelope.name, AttributeType.VEnvelope.name, AttributeType.VSemblance.name,
                 AttributeType.VFrequency.name, AttributeType.VPhase.name, AttributeType.VCosPhase.name, AttributeType.FaultHigh]

        # get custom attributes
        files = os.listdir(self.custom_attr_dir)
        custom_attr_files = list(filter(lambda x: "_attribute.py" in x, files))
        # print(custom_attr_files)
        module_name = "customattr"
        for f in custom_attr_files:
            full_path = self.custom_attr_dir + '/' + f
            loader = imp.machinery.SourceFileLoader(module_name, full_path)
            m = loader.load_module()
            for n in inspect.getmembers(m, inspect.isclass):
                attr_name = n[1].__name__
                if attr_name in attrs:
                    continue
                attrs.append(attr_name)

        return attrs
