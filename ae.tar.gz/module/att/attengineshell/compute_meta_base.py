

# base class for compute metadata class
class ComputeMetaDataBase(object):
    # constructor
    def __init__(self, **kwargs):
        pass

    # get attribute parameters if it has one
    def get_parameters(self):
        pass

    # get supported attributes
    def get_attributes(self):
        pass

