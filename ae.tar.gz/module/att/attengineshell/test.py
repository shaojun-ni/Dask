def joke():
    print('This is a joke')
    return ('here')
