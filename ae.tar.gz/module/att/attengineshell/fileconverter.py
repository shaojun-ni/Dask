import numpy as np
import os
import re
import zarr
import dask
from geoio.geoio import GeoIoVolume, SpVerticalTraceHeaderArray, SpVerticalTraceCheckArray


class FileConverter:
    @staticmethod
    def createtempheader() -> (SpVerticalTraceHeaderArray, SpVerticalTraceCheckArray):
        header = SpVerticalTraceHeaderArray()
        header.bits_per_sample = 8
        header.min_clip_amp = -1000
        header.max_clip_amp = 1000
        header.inline_crossline = ord('I')
        header.track_direction = ord('D')
        header.bin_direction = ord('A')
        check = SpVerticalTraceCheckArray()
        check.track_dir = ord('V')
        check.num_tracks = 10
        check.num_bins = 20
        check.num_samples = 30

        return header, check

    @staticmethod
    def numpyarray_2_vt(numpy_array, vt_file, numpy_file, original_path,
                        max_amplify=1, in_max_value=None, in_min_value=None):
        print('numpyarray_2_vt:Read original file header')

        tempheader, tempcheck = FileConverter.createtempheader()
        tempcheck.num_tracks = int(numpy_array.shape[0])
        tempcheck.num_bins = int(numpy_array.shape[1])
        tempcheck.num_samples = int(numpy_array.shape[2])

        if in_max_value is None:
            max_value = float(numpy_array.max()) * max_amplify
            min_value = -max_value
        else:
            max_value = in_max_value
            min_value = in_min_value

        print('max={0}, min={1}'.format(max_value, min_value))
        if original_path:
            if os.path.isfile(original_path):
                existing_vt_filename = original_path
            else:
                filepath = os.path.basename(numpy_file)
                original_name = os.path.splitext(filepath)[0] + '.vt'
                existing_vt_filename = original_path + '/' + original_name

            print('vt header file name:' + existing_vt_filename)
            if os.path.exists(existing_vt_filename):
                existing_volume = GeoIoVolume(existing_vt_filename)
                header, check = existing_volume.get_header_info()
                header.max_clip_amp = max_value
                header.min_clip_amp = min_value
                # Create new volume
                vt = GeoIoVolume(vt_file, header, check)
            else:
                tempheader.max_clip_amp = max_value
                tempheader.min_clip_amp = min_value
                vt = GeoIoVolume(vt_file, tempheader, tempcheck)
        else:
            tempheader.max_clip_amp = max_value
            tempheader.min_clip_amp = min_value
            vt = GeoIoVolume(vt_file, tempheader, tempcheck)

        print('Create new vt file.')
        vt.put(numpy_array)

    @staticmethod
    def numpyfile_2_vt(numpy_file, vt_file, original_path):
        print('Load data from numpy')
        npdata = np.load(numpy_file)
        FileConverter.numpyarray_2_vt(npdata, vt_file, numpy_file, original_path)

    @staticmethod
    def convert_zarr_2_numpyarray(zarrfile):
        numpyarray = zarr.open(zarrfile, mode='r')
        return np.array(numpyarray)

    @staticmethod
    def zarr_2_numpyfile(zarrfile, outputpath):
        numpyarray = zarr.open(zarrfile, mode='r')
        np.save(outputpath, numpyarray)

    @staticmethod
    def zarr_2_vt(zarr_file, vt_file, original_path, max_amplify=1, max_value=None, min_value=None):
        numpy_array = FileConverter.convert_zarr_2_numpyarray(zarr_file)
        FileConverter.numpyarray_2_vt(numpy_array, vt_file, zarr_file, original_path, max_amplify, max_value, min_value)

    @staticmethod
    def vt_2_numpyfile(vt_file, numpy_file, data_type='float'):
        volume = GeoIoVolume(vt_file)
        if data_type == 'float':
            narray = np.array(volume.get_float())
        else:
            narray = np.array(volume.get_byte())
        np.save(numpy_file, narray)

    @staticmethod
    def npmpyfile_2_zarr(numpy_file, outputpath, x_size, y_size, z_size, usecompressor):
        print('Loading numpy file {0} ...'.format(numpy_file))
        filepath = os.path.basename(numpy_file)
        npdata = np.load(numpy_file)
        print('input data size = {0}, data shape = {1}, data type = {2}'.format(npdata.size, npdata.shape, npdata.dtype))
        name = os.path.splitext(filepath)[0]
        FileConverter.numpyarray_2_zarr(npdata, name, outputpath, x_size, y_size, z_size, usecompressor)

    @staticmethod
    def numpyarray_2_zarr(npdata, filename, outputpath, x_size, y_size, z_size, usecompressor):

        item = outputpath + '/' + filename
        store = zarr.DirectoryStore(item)
        group = zarr.hierarchy.group(store=store, overwrite=True, synchronizer=zarr.ThreadSynchronizer())

        the_var = filename + '.zarr'
        if not usecompressor:
            out_zarr = group.zeros(the_var, shape=npdata.shape, dtype=npdata.dtype, compressor=None,
                                   chunks=[x_size, y_size, z_size])
        else:
            out_zarr = group.zeros(the_var, shape=npdata.shape, dtype=npdata.dtype, chunks=[x_size, y_size, z_size])

        out_zarr[...] = npdata[...]

        return '{0}/{1}/{1}.zarr'.format(outputpath, filename)

    @staticmethod
    def vt_2_zarr(vt_file, outputpath, x_size, y_size, z_size, usecompressor, data_type='float'):
        filepath = os.path.basename(vt_file)
        volume = GeoIoVolume(vt_file)
        header, check = volume.get_header_info()
        if data_type == 'float':
            npdata = np.array(volume.get_float())
        else:
            npdata = np.array(volume.get_byte())
        print('load data to numpy array.')

        name = os.path.splitext(filepath)[0]
        zarr_file_name = FileConverter.numpyarray_2_zarr(npdata, name, outputpath, x_size, y_size, z_size,
                                                         usecompressor)
        item = outputpath + '/' + name
        vtheaderfilename = item + '/' + name + '.vt'
        print('vt header filename is:' + vtheaderfilename)

        vt = GeoIoVolume(vtheaderfilename, header, check)
        return zarr_file_name

    @staticmethod
    def vt_2_vts_by_bin(vt_file, output, number_of_files, overlap):
        intercept = GeoIoVolume(vt_file)
        header, check = intercept.get_header_info()

        print(check.num_tracks)
        print(check.num_bins)
        print(check.num_samples)

        step = int(check.num_bins / number_of_files)

        print('Split to number of files:{0}'.format(number_of_files))
        print('Number of bin in a file:{0}'.format(step))
        print('Overlap bin:{0}'.format(overlap))

        if step <= overlap:
            print('overlap bins is more than bins in a file.')
            return

        for count in range(0, number_of_files):
            index = count * step
            output_filename = '{0}_{1}.vt'.format(output, count)
            print('output file_name:' + output_filename)
            slice_1 = (index, 0, 0)

            if count == number_of_files - 1:  # index + step > check.num_bins - 1:
                slice_2 = (check.num_bins - 1, check.num_tracks - 1, check.num_samples - 1)
            else:
                slice_2 = (index + step - 1 + overlap, check.num_tracks - 1, check.num_samples - 1)

            new_vt = GeoIoVolume(output_filename, header, check)
            print(slice_1)
            print(slice_2)
            input_data = intercept.get_float(slice_1, slice_2)

            new_vt.put(input_data, slice_1, slice_2)

    @staticmethod
    def combine_vts_2_vt(input_path, original_vt_path, output_file, overlap):
        original_vt = GeoIoVolume(original_vt_path)
        header, check = original_vt.get_header_info()

        print("original vt tracks: ", check.num_tracks)
        print("original vt bins: ", check.num_bins)
        print("original vt samples: ", check.num_samples)

        for path, dirs, files in os.walk(input_path):
            continue

        files.sort()
        print(files)
        print(path)

        number_files = len(files)
        step = int(check.num_bins / number_files)
        output_vt = GeoIoVolume(output_file, header, check)

        count = 0
        for filename in files:
            f = path + '/' + filename
            print(f)
            index = count * step
            vt = GeoIoVolume(f)
            slice_1 = (index, 0, 0)

            if count == number_files - 1:
                slice_2 = (check.num_bins - 1, check.num_tracks - 1, check.num_samples - 1)
            else:
                slice_2 = (index + step - 1, check.num_tracks - 1, check.num_samples - 1)

            print(slice_1)
            print(slice_2)
            input_data = vt.get_float(slice_1, slice_2)
            output_vt.put(input_data, slice_1, slice_2)

    @staticmethod
    def vt_2_zarr_internal(vt_handle, slice_1, slice_2, group, name, size_x, size_y, size_z, data_type='float'):
        #print("slice1--slice2", slice_1, slice_2)
        if data_type == 'float':
            input_data = vt_handle.get_float(slice_1, slice_2)
        else:
            input_data = vt_handle.get_byte(slice_1, slice_2)

        out_zarr = group.zeros(name, shape=input_data.shape, dtype=input_data.dtype, compressor=None,
                               chunks=[size_x, size_y, size_z])
        out_zarr[...] = input_data[...]
        return name


    @staticmethod
    def vt_2_zarr_internal_simple(vt_handle, slice_1_x, slice_1_y, slice_1_z, slice_2_x, slice_2_y, slice_2_z, group, name, size_x, size_y, size_z, data_type='float'):
        #print("slice1--slice2", slice_1, slice_2)
        slice_1 = (slice_1_x, slice_1_y, slice_1_z)
        slice_2 = (slice_2_x, slice_2_y, slice_2_z)
        if data_type == 'float':
            input_data = vt_handle.get_float(slice_1, slice_2)
        else:
            input_data = vt_handle.get_byte(slice_1, slice_2)

        out_zarr = group.zeros(name, shape=input_data.shape, dtype=input_data.dtype, compressor=None,
                               chunks=[size_x, size_y, size_z])
        out_zarr[...] = input_data[...]
        return name

    @staticmethod
    def vt_2_zarrs_by_bin(vt_file, outputpath, number_of_files, overlap, size_x, size_y, size_z, data_type):
        vt_handle = GeoIoVolume(vt_file)
        header, check = vt_handle.get_header_info()

        print(check.num_tracks)
        print(check.num_bins)
        print(check.num_samples)


        if check.track_dir == ord("H"):     #switch bin and tracks if track_dir = V
            num_bins = check.num_bins
            num_tracks = check.num_tracks
        else:
            num_bins = check.num_tracks
            num_tracks = check.num_bins

        step = int(num_bins / number_of_files)


        print('Split to number of files:{0}'.format(number_of_files))
        print('Number of bin in a file:{0}'.format(step))
        print('Overlap bin:{0}'.format(overlap))
        if size_x >= step:
            size_x = int(step / 2)

        print('size_x:{0}'.format(size_x))
        print('size_y:{0}'.format(size_y))
        print('size_z:{0}'.format(size_z))

        if step <= overlap:
            print('overlap bins is more than bins in a file.')
            return

        filepath = os.path.basename(vt_file)
        name = os.path.splitext(filepath)[0]
        item = outputpath + '/' + name
        print("input zarr path: ", item)
        store = zarr.DirectoryStore(item)
        group = zarr.hierarchy.group(store=store, overwrite=True, synchronizer=zarr.ThreadSynchronizer())

        #### Loop over Bins
        for count in range(0, number_of_files):
            index = count * step
            the_var = '{0}_{1}.zarr'.format(name, count)
            print(the_var)
            slice_1 = (index, 0, 0)

            if count == number_of_files - 1:
                slice_2 = (num_bins - 1, num_tracks - 1, check.num_samples - 1)
            else:
                slice_2 = (index + step - 1 + overlap, num_tracks - 1, check.num_samples - 1)

            FileConverter.vt_2_zarr_internal(vt_handle, slice_1, slice_2, group, the_var, size_x, size_y, size_z, data_type)
            count += 1

    @staticmethod
    def vt_2_zarrs_by_bin_parallel(vt_file, outputpath, number_of_files, overlap, size_x, size_y, size_z, data_type):
        vt_handle = GeoIoVolume(vt_file)
        header, check = vt_handle.get_header_info()

        print(check.num_tracks)
        print(check.num_bins)
        print(check.num_samples)

        step = int(check.num_bins / number_of_files)

        print('Split to number of files:{0}'.format(number_of_files))
        print('Number of bin in a file:{0}'.format(step))
        print('Overlap bin:{0}'.format(overlap))
        if size_x >= step:
            size_x = int(step / 2)

        print('size_x:{0}'.format(size_x))
        print('size_y:{0}'.format(size_y))
        print('size_z:{0}'.format(size_z))

        if step <= overlap:
            print('overlap bins is more than bins in a file.')
            return

        filepath = os.path.basename(vt_file)
        name = os.path.splitext(filepath)[0]
        item = outputpath + '/' + name
        print("input zarr path: ", item)
        store = zarr.DirectoryStore(item)
        group = zarr.hierarchy.group(store=store, overwrite=True, synchronizer=zarr.ThreadSynchronizer())

        #### Loop over Bins
        outputZarrs = []
        for count in range(0, number_of_files):
            index = count * step
            the_var = '{0}_{1}.zarr'.format(name, count)
            print(the_var)
            slice_1 = (index, 0, 0)

            if count == number_of_files - 1:
                slice_2 = (check.num_bins - 1, check.num_tracks - 1, check.num_samples - 1)
            else:
                slice_2 = (index + step - 1 + overlap, check.num_tracks - 1, check.num_samples - 1)

            slice_1_x = slice_1[0]
            slice_1_y = slice_1[1]
            slice_1_z = slice_1[2]

            slice_2_x = slice_2[0]
            slice_2_y = slice_2[1]
            slice_2_z = slice_2[2]

            res = dask.delayed(FileConverter.vt_2_zarr_internal_simple)(vt_handle, slice_1_x, slice_1_y, slice_1_z, slice_2_x, slice_2_y, slice_2_z, group, the_var, size_x, size_y, size_z,
                                             data_type)
            outputZarrs.append(res)
            print("count = ", count)
            count += 1
        print(dask.compute(*outputZarrs))
        #print(outputZarrs.compute())

    @staticmethod
    def combine_zarrs_2_vt(input_path, original_vt_path, output_file, overlap, min_value=None, max_value=None):
        original_vt = GeoIoVolume(original_vt_path)
        header, check = original_vt.get_header_info()

        if min_value is not None:
            header.min_clip_amp = float(min_value)
        if max_value is not None:
            header.max_clip_amp = float(max_value)

        print("original vt tracks: ", check.num_tracks)
        print("original vt bins: ", check.num_bins)
        print("original vt samples: ", check.num_samples)

        tt = {}
        for path, dirs, files in os.walk(input_path, topdown=False):
            for d in dirs:
                p = input_path + '/' + d
                t = re.findall('\\d+', p)
                tt[int(t[len(t) - 1])] = d
                print(t)

        number_of_files = len(tt.keys())

        if check.track_dir == ord("H"):     #switch bin and tracks if track_dir = V
            num_bins = check.num_bins
            num_tracks = check.num_tracks
        else:
            num_bins = check.num_tracks
            num_tracks = check.num_bins

        step = int(num_bins / number_of_files)

        print('Merge file...')
        output_vt = GeoIoVolume(output_file, header, check)
        count = 0
        for k in sorted(tt.keys()):
            f = path + '/' + tt[k]
            print(f)

            zarray = zarr.open(f, mode='r')
            index = count * step
            slice_1 = (index, 0, 0)
            chunk = step
            if count == number_of_files - 1:
                slice_2 = (num_bins - 1, num_tracks - 1, check.num_samples - 1)
                chunk = num_bins - index
            else:
                slice_2 = (index + step - 1, num_tracks - 1, check.num_samples - 1)

            print('data slice {0}-{1}'.format(slice_1, slice_2))
            input_data = np.array(zarray)[0: chunk]
            output_vt.put(input_data, slice_1, slice_2)
            count += 1
