import numpy as np
import matplotlib.pyplot as plt

def plot_result_v01(out):
    # img = np.rot90(out[100,1:300,1:400],1)
    plt.imshow(out, aspect='auto')
    plt.tight_layout()