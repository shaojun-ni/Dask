import attengineshell


def main():
    print(attengineshell.joke())
