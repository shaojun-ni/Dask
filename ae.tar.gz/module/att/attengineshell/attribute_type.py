import enum


class AttributeType(enum.Flag):
    Non = 0
    Semblance = 1
    Envelope = 2
    Instantaneous = 4
    Custom = 8
    SharpSemblance = 16
    VEnvelope = 32
    VSemblance = 64
    VFrequency = 128
    VPhase = 256
    VCosPhase = 512
    FaultHigh = 1024
