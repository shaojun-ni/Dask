import sys
# import attengineshell
# sys.path.insert(0, "/glb/data/cdis_projects/users/usnrej/attEngine/module/att/")

# import algorithms

from att import attengineshell

import att

# import attengineshell
# print(list(att))
attengineshell.joke()
attengineshell.AttEngine()

