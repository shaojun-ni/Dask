import attengineshell as ate
import numpy as np


# sample custom attribute class without parameters
class abc(ate.AttributeBase):
    # constructor
    def __init__(self, in_file, out_file, use_compressor=False):
        super(abc, self).__init__(in_file, out_file, overlap=False, use_compressor_output=use_compressor)

    # get parameters definition
    @staticmethod
    def get_parameters():
        return ""

    # compute envelope attribute
    def _map_func(self, chunkdata):
        return np.absolute(chunkdata*2)

    #def hello_world(self):
    #    print('Hello World')
