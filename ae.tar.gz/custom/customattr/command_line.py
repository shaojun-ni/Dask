import customattr


def main():
    print(customattr.joke())
