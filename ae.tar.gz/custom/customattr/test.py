def joke():
    print('This is a custom joke')
    return ('here')
