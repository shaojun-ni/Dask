from setuptools import setup

setup(
    name='customattr',
    version='0.1',
    description='This is the custom attributes',
    url='http://attribute-engine',
    packages=['customattr'],
    install_requires=[
        'numpy==1.16.4',
    ],
    python_requires='>=3',
    scripts=['bin/entry-aecustom'],
    entry_points={
        'console_scripts': ['entryae_custom=customattr.command_line:main'],
    },
    zip_safe=False)
