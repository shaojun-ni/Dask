#!/bin/bash

echo .$1

if [[ $1 =~ .*\_attribute.py$ ]]; then
   echo "File pattern matches"
else
   echo "$1 does not end with _attribute.py"
   exit
fi

if [[ $1 =~ (.+).py ]]; then
    str_filename=${BASH_REMATCH[1]}
fi

if [[ $1 =~ (.+)_attribute.py ]]; then
    str_attrname=${BASH_REMATCH[1]}
fi

echo "file name is $str_filename"
echo "attribute name is $str_attrname"

cp -f $1 customattr
str="from .$str_filename import $str_attrname" 
echo $str

if grep "$str" customattr/__init__.py
then
   echo "$str already in __init__.py."
else
   echo $str >> customattr/__init__.py
fi

python setup.py develop


