
from geoio import GeoIoVolume

import numpy as np
import matplotlib.pyplot as plt

from semblance import semblance
from timeit import default_timer as timer

import dask

import dask.array as da

from dask import delayed
from dask.distributed import Client
from dask.distributed import progress

import os
import webbrowser
import gc

if __name__ == "__main__":

   # Parameter needs to be adjusted
   chunkx, chunky, chunkz =700,700,700
   wx, wy, wz = 1, 1, 4
 
   # Step 1 Define the input volume input
   print('Step1: Reading the info for the input vt \n')
   vt = GeoIoVolume('/glb/data/CDIS2/users/uslji0/Mars/sdd.ap-sdd.03-qcvol_rtm-90_30000.vt')
   survey = vt.get_survey()
   header,checker=vt.get_header_info()
   nx , ny , nz = checker.num_bins, checker.num_tracks, checker.num_samples
   print('...The input cube size is ',nx,'(num_bins) x',ny,'(num_tracks) x',nz,'(num_samples)\n')   

   sizex = np.ceil( nx/chunkx).astype(int)
   sizey = np.ceil( ny/chunky).astype(int)
   sizez = np.ceil( nz/chunkz).astype(int)

   print('...The cube will be divided into', sizex,' x', sizey,'x',sizez, '=', sizex*sizey*sizez,'pieces\n')

   print('Step 2: Creating the output semblance volume \n')

   header.bits_per_sample = 32
   header.min_clip_amp = 0
   header.max_clip_amp = 1

   try:
      os.remove('semblance.vt')
   except OSError:
      pass
   outputvt = GeoIoVolume('semblance.vt',header,checker)

   print('Step 3: Connecting to clusters\n') 
   client = Client()
   print('...Cluster info:',client,'\n')

   cinfo = client.scheduler_info()                                                                          
   port = cinfo['services']['bokeh']                                                                             
   url = cinfo['address'].replace('tcp','http').split(':')
   print('...Open diagnostic webpage...')
   webbrowser.open(url[0]+':'+url[1]+':'+str(port))                                                         
  
   print('Step 4 : Computing the semblance \n')
   for ix in range(sizex):
       for iy in range(sizey): 
           for iz in range(sizez): 

               xbeg, xend = ix * chunkx, min((ix+1)*chunkx-1,nx-1)
               ybeg, yend = iy * chunky, min((iy+1)*chunky-1,ny-1)
               zbeg, zend = iz * chunkz, min((iz+1)*chunkz-1,nz-1)
               print('...Processing',ix*sizey*sizez+iy*sizez+iz+1, 'out of ', sizex*sizey*sizez,'x:[',xbeg,',',xend,']; y:[',ybeg,',',yend,']; z:[',zbeg,',',zend,']\n')
               rxbeg, rxend = max(0,xbeg-wx), min(nx-1, xend+wx)
               rybeg, ryend = max(0,ybeg-wy), min(ny-1, yend+wy)
               rzbeg, rzend = max(0,zbeg-wz), min(nz-1, zend+wz)
               #print('...Processing x:[',rxbeg,',',rxend,']; y:[',rybeg,',',ryend,']; z:[',rzbeg,',',rzend,']\n')
  
               data = vt.get_float((rxbeg,rybeg,rzbeg),(rxend,ryend,rzend))
               daskdata = da.from_array(data,chunks=data.shape)
               chunkdata=daskdata.rechunk((400,400,400)).persist()

               print('......Rechunking the dataset ...\n')
               progress(chunkdata)
               print('\n')
               try: 
#                 wait(chunkdata)
                 client.rebalance(chunkdata)
               except:
                 client.rebalance(chunkdata)

               decomposed_data = da.ghost.ghost_internal(chunkdata, {0:wx,1:wy,2:wz})
               daskout = decomposed_data.map_blocks(semblance).persist()
               print('......Calculating the semblance ...\n')
               progress(daskout)
               print('\n')
               #client.rebalance(daskout)
               result = da.ghost.trim_internal(da.ghost.add_dummy_padding(daskout,{0:wx,1:wy,2:wz},{0:'none',1:'none',2:'none'}),{0:wx,1:wy,2:wz})
               print('......Output data to disk...\n')
               outputvt.put(np.array(result[xbeg-rxbeg:xend-rxbeg+1,ybeg-rybeg:yend-rybeg+1,zbeg-rzbeg:zend-rzbeg+1]),(xbeg,ybeg,zbeg),(xend,yend,zend))
               del(data)
               client.cancel(chunkdata)
               client.cancel(daskout)
               gc.collect()
   client.close()
   print('Done')

