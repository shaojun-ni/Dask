#ifndef UTILITIES_H 
#define UTILITIES_H

#include <DAGBase/ByteDataCube.h>
#include <DAGBase/DataTypes.h>
#include <DAGBase/Point.h>

#include <SeismicFilters/TypeBuffer.H>

using namespace DAG::Base;
using namespace VSF;


void ArrayDataToTypeBuffer(uint8* data, TypeBuffer<uint8>& buffer, int sizex, int sizey, int sizez);

void TypeBufferToByteCube(TypeBuffer<uint8>& buffer, ByteDataCube& cube);

std::vector<uint8> TypeBufferToArray(TypeBuffer<uint8>& buffer, int sizex, int sizey, int sizez, int leng);

void ExportBuffer(const TypeBuffer<uint8>& buffer, const std::string& name);

#endif
