import sys
import os
import numpy as np
import matplotlib.pyplot as plt
import geoio as gio
import voice.sharp_semblance_wrap as ss
import voice.complex_wrap as cp
import voice.fault_high_wrap as fh

from geoio.geoio import GeoIoVolume, SpVerticalTraceHeaderArray, SpVerticalTraceCheckArray


#vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismic2.vt'
#vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/BiggieMax_ft.vt'
vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismicCube.vt'
#vt_file = "/glb/data/CDIS2/users/usllp8/Repos/attribute_engine/src/Dask/data/seismic.vt"
att_file = "/glb/data/CDIS2/users/usllp8/Repos/attribute_engine/src/Dask/data/attribute.vt"

if os.path.isfile(att_file):
    os.remove(att_file)

volume = GeoIoVolume(vt_file)
header, check = volume.get_header_info()
i = volume.num_i()
j = volume.num_j()
k = volume.num_k()
data = volume.get_float()
print("i,j,k= ", i, j, k)
print(data.shape)
dst = fh.run(data,i, j, k, 1, 1, 1, 2, 10, 2) 


#dst = ss.run(data, i, j, k, 3, 3, 11)
#dst = cp.run('ENVELOPE', data, i, j, k, 27)
#dst = cp.run('FREQUENCY', data, i, j, k, 27)
#dst = cp.run('PHASE', data, i, j, k, 27)
#dst = cp.run('COSINE_PHASE', data, i, j, k, 27)
dst_cp = np.reshape(dst, (i, j, k))

header.min_clip_amp = 0.0
header.max_clip_amp = 1.0
out = GeoIoVolume(att_file, header, check)
out.put(dst_cp)

narray = np.array(out.get_float())
plt.figure(1)
plt.imshow(np.rot90(narray[150, :, :], 3), aspect='auto')
plt.show()

