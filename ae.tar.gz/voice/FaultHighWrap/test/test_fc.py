import sys
#sys.path.append(r'/glb/data/CDIS2/users/ushlip/miniconda3/envs/pvenv/lib/site-packages/voice')
import os
import numpy as np
import matplotlib.pyplot as plt
import geoio as gio
import voice.sharp_semblance_wrap as wp
import attengineshell.fileconverter as fc

from geoio.geoio import GeoIoVolume, SpVerticalTraceHeaderArray, SpVerticalTraceCheckArray

vt_file = '../data/seismicCube_2017.69393739.vt'
att_vt_file = '../data/att_seismicCube_2017.vt'

output = '../output'

zarr_file = fc.FileConverter.vt_2_zarr_byte(vt_file, output, 300, 300, 800, False)

if os.path.isfile(att_vt_file):
    os.remove(att_vt_file)

volume = GeoIoVolume(vt_file)
header, check = volume.get_header_info()
i = volume.num_i()
j = volume.num_j()
k = volume.num_k()
data = volume.get_byte()

dst = wp.Run(data, i, j, k, 3, 3, 11)
dst_cp = np.reshape(dst, (i, j, k))

header.min_clip_amp = 0.0
header.max_clip_amp = 1.0
out = GeoIoVolume(att_vt_file, header, check)
out.put(dst_cp)

narray = np.array(out.get_float())
plt.figure(1)
plt.imshow(np.rot90(narray[150, :, :], 3), aspect='auto')
plt.show()
