import sys
import os
import fileconverter as fc

import matplotlib.pyplot as plt
import numpy as np


#data_path = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/'
#vase_name = 'new4'
#vt_file = data_path + base_name + '.vt'
#npy_file = data_path + base_name + '.npy'


#vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismic.vt'
#np_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismic.npy'
#vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/dataOut/seismic_sharpsemblance.vt'
#np_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/dataOut/seismic_sharpsemblance.npy'

#vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismic2.vt'
#np_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismic2.npy'
#vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/dataOut/seismic2_sharpsemblance.vt'
#np_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/dataOut/seismic2_sharpsemblance.npy'

#vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismicCube_2017.69393739.vt'
#np_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismicCube_2017.69393739.npy'
# vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismicCube_2017.69393739_envelope.vt'
# np_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismicCube_2017.69393739_envelope.npy'
vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismicCube_2017.69393739_phase.vt'
np_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismicCube_2017.69393739_phase.npy'

#vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/dataOut/seismicCube_2017.69393739_sharpsemblance.vt'
#np_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/dataOut/seismicCube_2017.69393739_sharpsemblance.npy'

#vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/new4.vt'
#np_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/new4.npy'
#vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/dataOut/new4_sharpsemblance.vt'
#np_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/dataOut/new4_sharpsemblance.npy'

#vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/BiggieMax_ft.vt'
#np_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/BiggieMax_ft.npy'
# vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/dataOut/BiggieMax_ft_sharpsemblance.vt'
# np_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/dataOut/BiggieMax_ft_sharpsemblance.npy'

if os.path.isfile(np_file):
	print('npy file exist')
else:
	fc.FileConverter().vt_2_numpyfile(vt_file, np_file)

#fc.FileConverter().vt_2_numpyfile(vt_file, np_file)

x = np.load(np_file)

print(x.shape)
plt.figure(1)
plt.imshow(np.rot90(x[150, :, :], 3), aspect='auto')
plt.show()
