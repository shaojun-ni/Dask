#include <boost/python.hpp>
#include <boost/python/numpy.hpp>
#include <iostream>
#include <fstream>

#include "SeismicFilters/SharpSemblance.H"
#include "SeismicFilters/TypeBuffer.H"
#include "DAGBase/DataTypes.h"

using namespace boost::python;
using namespace VSF;
using namespace DAG::Base;

namespace np = boost::python::numpy;

np::ndarray run(const numpy::ndarray& bytes, int sizex, int sizey, int sizez, int fsx, int fsy, int fsz)
{
	if (sizex * sizey *sizez == 0)
	{
		Py_intptr_t shape[1] = { sizex*sizey*sizez };
		return np::zeros(1, shape, np::dtype::get_builtin<uint8>());
	}
	
	SharpSemblance sb = SharpSemblance(sizez, fsx, fsy, fsz, false, true, 1);

   uint8* inBuffer = reinterpret_cast<uint8*>(bytes.get_data());
	signed32_64 psz = 1;
	signed32_64 psy = sizez;
	signed32_64 psx = psy * sizey;

   TypeBuffer<uint8> srcIm(inBuffer, sizex, sizey, sizez, psx, psy, psz, 1, 1, 1);
   srcIm.alignToBorder(true);

   DataOrdering order = srcIm.order();	
   TypeBuffer<uint8> dstIm(sizex, sizey, sizez , 1, 1, 1, order);

   sb.run<uint8>(srcIm, dstIm, 1, 0, 0, 0);

	uint8* data = dstIm.pOrigin();	
	Py_intptr_t shape[1] = { sizex*sizey*sizez };
	np::ndarray result = np::zeros(1, shape, np::dtype::get_builtin<uint8>());
	std::copy(data, data + sizex*sizey*sizez, reinterpret_cast<uint8*>(result.get_data()));
	return result;
}

BOOST_PYTHON_MODULE(sharp_semblance_wrap)
{
	boost::python::numpy::initialize();
	def("run", run);
}
