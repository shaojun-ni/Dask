import sys
import os
import numpy as np
import matplotlib.pyplot as plt
import voice.voice_wrap as vw

from geoio.geoio import GeoIoVolume, SpVerticalTraceHeaderArray, SpVerticalTraceCheckArray

#vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismic.vt'
#vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/BiggieMax_ft.vt'
vt_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/seismicCube.vt'
att_file = '/glb/data/CDIS2/users/ushlip/attribute_engine/src/Dask/data/attribute.vt'

if os.path.isfile(att_file):
    os.remove(att_file)

volume = GeoIoVolume(vt_file)
header, check = volume.get_header_info()
data = volume.get_byte()

i, j, k = data.shape
# dst = vw.sharp_semblance_run(data, i, j, k, 3, 3, 11)
# dst = vw.semblance_run(data, i, j, k, 3, 3, 11)
# dst = vw.complex_trace_run('ENVELOPE', data, i, j, k, 27)
# dst = vw.complex_trace_run('FREQUENCY', data, i, j, k, 27)
# dst = vw.complex_trace_run('PHASE', data, i, j, k, 27)
dst = vw.complex_trace_run('COSINE_PHASE', data, i, j, k, 27)

dst_cp = np.reshape(dst, (i, j, k))

header.min_clip_amp = -1.0
header.max_clip_amp = 1.0
out = GeoIoVolume(att_file, header, check)
out.put(dst_cp)

narray = np.array(out.get_float())
#narray = np.array(dst_cp)
plt.figure(1)
plt.imshow(np.rot90(narray[150, :, :], 3), aspect='auto')
plt.show()
