#include <vector>

#include <boost/python.hpp>
#include <boost/python/numpy.hpp>

#include <Utilities.h>

#include <SeismicFilters/Complex1.H>
#include <SeismicFilters/PhaseShift.H>
#include <SeismicFilters/TypeBuffer.H>

#include <DAGAttributes/ZeroCrossing.h>
#include <DAGBase/ByteDataCube.h>
#include <DAGBase/DataTypes.h>
#include <DAGBase/DataTypes.h>
#include <DAGBase/Point.h>
#include <DAGVGSVolume/Volume.h>

using namespace boost::python;
using namespace DAG::Base;
using namespace DAG::Attributes;
using namespace VSF;

namespace np = boost::python::numpy;

VSF::ComplexOperation toVsfOperation(const std::string& operation)
{
	if (operation == "ENVELOPE")
		return VSF::ENVELOPE;
	else if (operation == "FREQUENCY")
		return VSF::FREQUENCY;
	else if (operation == "PHASE")
		return VSF::PHASE;
	else if (operation == "COSINE_PHASE")
		return VSF::COSINE_PHASE;
}

np::ndarray complex_trace_run(const std::string& complexOp, const numpy::ndarray& bytes, int sizex, int sizey, int sizez, int leng)
{
	if (sizex * sizey *sizez == 0)
	{
		Py_intptr_t shape[1] = { 0 };
		return np::zeros(1, shape, np::dtype::get_builtin<uint8>());
	}

	uint8* inBuffer = reinterpret_cast<uint8*>(bytes.get_data());

	Point footprint(1, 1, leng + 2);
	Point phaseShiftFootprint(1, 1, leng);
	Point complexFootprint(1, 1, 3);

	DataOrdering order = ORDER_ZYX;
	TypeBuffer<uint8> srcBrick(sizex, sizey, sizez, footprint.i, footprint.j, footprint.k, order);
	ArrayDataToTypeBuffer(inBuffer, srcBrick, sizex, sizey, sizez);

	TypeBuffer<uint8> phaseBrick(sizex, sizey, sizez, footprint.i, footprint.j, footprint.k, order, true);
	TypeBuffer<uint8> dstBrick(sizex, sizey, sizez, footprint.i, footprint.j, footprint.k, order, true);

	// Fixed parameter values:
	const float64 zeroCrossing  = ZeroCrossing<uint8>::zeroCrossing(0.0);
	const float64 phaseShift = (90.0 * M_PI) / 180.0;
	const int32 percentFlat = 80;

	VSF::PhaseShift phaseShiftObj(phaseShiftFootprint.k, percentFlat, phaseShift, zeroCrossing);
	VSF::Complex1 complex1Obj(toVsfOperation(complexOp), zeroCrossing);

	// Setup the buffers for phase shift:
	srcBrick.shrink(phaseShiftFootprint.i / 2, phaseShiftFootprint.j / 2, phaseShiftFootprint.k / 2);
	phaseBrick.shrink(phaseShiftFootprint.i / 2, phaseShiftFootprint.j / 2, phaseShiftFootprint.k / 2);
	dstBrick.shrink(phaseShiftFootprint.i / 2, phaseShiftFootprint.j / 2, phaseShiftFootprint.k / 2);

	// Run the phase shift filter first:
	phaseShiftObj.run(srcBrick, phaseBrick, true, false);

	// Now set up the buffers for complex 1:
	// NOTE: complex 1 doesn't explicitly handle border regions so the valid region in the
	// type buffer must be expanded to cover the entire area to be written.
	srcBrick.alignToBorder(true);
	phaseBrick.alignToBorder(true);
	dstBrick.alignToBorder(true);
	srcBrick.shrink(complexFootprint.i / 2, complexFootprint.j / 2, complexFootprint.k / 2);
	phaseBrick.shrink(complexFootprint.i / 2, complexFootprint.j / 2, complexFootprint.k / 2);
	dstBrick.shrink(complexFootprint.i / 2, complexFootprint.j / 2, complexFootprint.k / 2);

	// Then run the complex 1 filter:
   complex1Obj.run<uint8>(srcBrick, phaseBrick, dstBrick);

	// Convert C array to numpy array
	std::vector<uint8> dataV = TypeBufferToArray(dstBrick, dstBrick.sizeX(), dstBrick.sizeY(), dstBrick.sizeZ(), 26);
	uint8* data = dataV.data();

	Py_intptr_t shape[1] = { sizex*sizey*sizez };
	np::ndarray result = np::zeros(1, shape, np::dtype::get_builtin<uint8>());
	std::copy(data, data + sizex*sizey*sizez, reinterpret_cast<uint8*>(result.get_data()));
	
	return result;
}
