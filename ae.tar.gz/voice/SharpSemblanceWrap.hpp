#include <boost/python.hpp>
#include <boost/python/numpy.hpp>

#include <Utilities.h>
#include "SeismicFilters/SharpSemblance.H"

#include <DAGBase/ByteDataCube.h>
#include <DAGBase/DataTypes.h>
#include <DAGBase/Point.h>

using namespace boost::python;
using namespace DAG::Base;
using namespace DAG::Attributes;
using namespace VSF;

namespace np = boost::python::numpy;


np::ndarray sharp_semblance_run(const numpy::ndarray& bytes, int sizex, int sizey, int sizez, int fsx, int fsy, int fsz)
{
	if (sizex * sizey *sizez == 0)
	{
		Py_intptr_t shape[1] = { sizex*sizey*sizez };
		return np::zeros(1, shape, np::dtype::get_builtin<uint8>());
	}
	
	SharpSemblance sb = SharpSemblance(sizez, fsx, fsy, fsz, false, true, 1);

   uint8* inBuffer = reinterpret_cast<uint8*>(bytes.get_data());
	signed32_64 psz = 1;
	signed32_64 psy = sizez;
	signed32_64 psx = psy * sizey;

   TypeBuffer<uint8> srcIm(inBuffer, sizex, sizey, sizez, psx, psy, psz, 1, 1, 1);
   srcIm.alignToBorder(true);

   DataOrdering order = srcIm.order();	
   TypeBuffer<uint8> dstIm(sizex, sizey, sizez , 1, 1, 1, order);

   sb.run<uint8>(srcIm, dstIm, 1, 0, 0, 0);

	uint8* data = dstIm.pOrigin();	
	Py_intptr_t shape[1] = { sizex*sizey*sizez };
	np::ndarray result = np::zeros(1, shape, np::dtype::get_builtin<uint8>());
	std::copy(data, data + sizex*sizey*sizez, reinterpret_cast<uint8*>(result.get_data()));
	return result;
}
