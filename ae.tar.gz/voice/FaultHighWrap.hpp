#include <boost/python.hpp>
#include <boost/python/numpy.hpp>
#include <iostream>
#include <fstream>

#include "SeismicFilters/VGFaultHigh.H"
#include "SeismicFilters/TypeBuffer.H"
#include "DAGBase/DataTypes.h"
#include "DAGBase/Point.h"
#include <stdint.h>

using namespace boost::python;
using namespace VSF;
using namespace DAG::Base;

namespace np = boost::python::numpy;

np::ndarray fault_high_run(const numpy::ndarray& floats, 
									int sizex, int sizey, int sizez, 
									int32_t localScale, int32_t structureScale, int32_t verticalStretch)
{
	if (sizex * sizey *sizez == 0)
	{
		Py_intptr_t shape[1] = { sizex*sizey*sizez };
		return np::zeros(1, shape, np::dtype::get_builtin<float>());
	}
	

	VGFaultHigh faultHighObj = VGFaultHigh(localScale,
                                           structureScale,
                                           verticalStretch);

	float* inBuffer = reinterpret_cast<float*>(floats.get_data());
	signed32_64 psz = 1;
	signed32_64 psy = sizez;
	signed32_64 psx = psy * sizey;

	Point footprint(1, 1, 1);

   //input buffer for kernel calculation
   TypeBuffer<float> srcBuf(inBuffer, sizex, sizey, sizez, psx, psy, psz, footprint.i, footprint.j, footprint.k);
   srcBuf.alignToBorder(true);

   //output buffer for kernel calculation
   DataOrdering order = srcBuf.order();
   TypeBuffer<float> dstBuf(sizex, sizey, sizez , footprint.i, footprint.j,  footprint.k, order);

   //temporary buffer for kernel calculation
   TypeBuffer<float> mxx(sizex, sizey, sizez , footprint.i, footprint.j,  footprint.k, order);
   TypeBuffer<float> trace1(sizex, sizey, sizez , footprint.i, footprint.j,  footprint.k, order);
   TypeBuffer<float> trace2(sizex, sizey, sizez , footprint.i, footprint.j,  footprint.k, order);
   TypeBuffer<float> diffIm(sizex, sizey, sizez , footprint.i, footprint.j,  footprint.k, order);
   TypeBuffer<float> tmpIm(sizex, sizey, sizez , footprint.i, footprint.j,  footprint.k, order);

   //extra parameter for kernel
   //const double typeScale  = VSF::isFloat(inType(0)) ? 1 : double(VSF::maxType(inType(0)));
   const double typeScale  = 1;
	const double typeOffset = 0.0;
   faultHighObj.run(	srcBuf,
						diffIm,
						tmpIm,
						trace1,
						mxx,
						trace2,
						dstBuf,
						typeScale,
						typeOffset );


	float* data = dstBuf.pOrigin();
	Py_intptr_t shape[1] = { sizex*sizey*sizez };
	np::ndarray result = np::zeros(1, shape, np::dtype::get_builtin<float>());
	std::copy(data, data + sizex*sizey*sizez, reinterpret_cast<float*>(result.get_data()));
	return result;
}
