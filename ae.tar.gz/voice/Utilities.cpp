#include <iostream>
#include <fstream>
#include <vector>

#include "Utilities.h"

#include <SeismicFilters/TypeBuffer.H>

#include <DAGBase/ByteDataCube.h>
#include <DAGBase/DataTypes.h>
#include <DAGBase/Point.h>

using namespace DAG::Base;
using namespace std;


void ArrayDataToTypeBuffer(uint8* data, TypeBuffer<uint8>& buffer, int sizex, int sizey, int sizez)
{
	DAG::Base::Point point(sizex, sizey, sizez);
	DAG::Base::ByteDataCube cube(point, data, ORDER_KJI);

	for(unsigned int k = 0; k < sizez; k++)
		for(unsigned int j = 0; j < sizey; j++)
			for(unsigned int i = 0; i < sizex; i++)
				buffer.set(i, j, k, cube.get<uint8>(i, j, k));

	buffer.alignToBorder(true);
}

void TypeBufferToByteCube(TypeBuffer<uint8>& buffer, ByteDataCube& cube)
{
	int sizex = buffer.sizeX();
	int sizey = buffer.sizeY();
	int sizez = buffer.sizeZ();
	const Point point(sizex, sizey, sizez);
	bool alignedToBorder = buffer.isAlignedToBorder();

	cube.resize( point );
	buffer.alignToBorder(true);

	// Copy the data to the output buffer.
	for(uint32 k = 0; k < point.k; k++)
		for(uint32 j = 0; j < point.j; j++)
			for(uint32 i = 0; i < point.i; i++)
				cube.set(i, j, k, buffer.get(i, j, k));

	buffer.alignToBorder(alignedToBorder);
}

std::vector<uint8> TypeBufferToArray(TypeBuffer<uint8>& buffer, int sizex, int sizey, int sizez, int leng)
{
	std::vector<uint8> v;
	v.reserve(sizex * sizey * (sizez - leng));
	int offset = leng/2;

	for(unsigned int i = 0; i < sizex; i++)
	{
		for(unsigned int j = 0; j < sizey; j++)
		{
			std::vector<uint8> line;
			line.reserve(sizez - leng);
			for(unsigned int k = offset; k < (sizez - offset); k++)
			{
				line.push_back(buffer.get(i, j, k));
			}
				std::copy(line.begin(), line.end(), std::back_inserter(v));
		}
	}

	buffer.alignToBorder(true);

	return v;
}

void ExportBuffer(const TypeBuffer<uint8>& buffer, const std::string& name)
{
	ofstream myfile;
	std::string fileName = "//glb/data//CDIS2//users//ushlip//attribute_engine//src//Dask//voice//SharpSemblanceWrap//test//" + name;
	myfile.open (fileName.c_str());

	int sizex = buffer.sizeX();
	int sizey = buffer.sizeY();
	int sizez = buffer.sizeZ();

	for(uint32 i = 0; i < sizex; i++)
	{
		for(uint32 j = 0; j < sizey; j++)
		{
			for(uint32 k = 0; k < sizez; k++)
			{
				myfile << (int)(buffer.get(i, j, k)) << " ";
			}
			myfile << endl;
		}
	}

	myfile.close();
}

