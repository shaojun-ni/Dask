#include <boost/python.hpp>
#include <boost/python/numpy.hpp>

#include <Utilities.h>
#include <SeismicFilters/2ndMoment.H>

#include <DAGAttributes/ZeroCrossing.h>
#include <DAGBase/ByteDataCube.h>
#include <DAGBase/DataTypes.h>
#include <DAGBase/Point.h>

using namespace boost::python;
using namespace DAG::Base;
using namespace DAG::Attributes;
using namespace VSF;

namespace np = boost::python::numpy;

np::ndarray semblance_run(const numpy::ndarray& bytes, int sizex, int sizey, int sizez, int fsx, int fsy, int fsz)
{
	if (sizex * sizey *sizez == 0)
	{
		Py_intptr_t shape[1] = { sizex*sizey*sizez };
		return np::zeros(1, shape, np::dtype::get_builtin<uint8>());
	}
	
   uint8* inBuffer = reinterpret_cast<uint8*>(bytes.get_data());
	DataOrdering order = ORDER_ZYX;
	TypeBuffer<uint8> srcBrick(sizex, sizey, sizez, fsx, fsy, fsz, order);
	ArrayDataToTypeBuffer(inBuffer, srcBrick, sizex, sizey, sizez);

	TypeBuffer<uint8> dstBrick(sizex, sizey, sizez, fsx, fsy, fsz, order);
	TypeBuffer<double> workBrick1(sizex, sizey, sizez, fsx, fsy, fsz, order);
	TypeBuffer<double> workBrick2(sizex, sizey, sizez, fsx, fsy, fsz, order);

	const double zeroCrossing = ZeroCrossing<uint8>::zeroCrossing(0.0);
	double notUsed1 =  DBL_MAX;
	double notUsed2 = -DBL_MAX;
	SecondMoment SecondMomentObj(SEMBLANCE, fsx, fsy, fsz, zeroCrossing, true, notUsed1, notUsed2);
																																					
	SecondMomentObj.run(srcBrick,
							workBrick1,
							workBrick2, 
							dstBrick,
							true, false,
							false, false,
							false, false);

	ByteDataCube cube(ORDER_KJI);
	TypeBufferToByteCube(dstBrick, cube);

	uint8* data = cube.getContents();
	Py_intptr_t shape[1] = { sizex*sizey*sizez };
	np::ndarray result = np::zeros(1, shape, np::dtype::get_builtin<uint8>());
	std::copy(data, data + sizex*sizey*sizez, reinterpret_cast<uint8*>(result.get_data()));
	return result;
}
