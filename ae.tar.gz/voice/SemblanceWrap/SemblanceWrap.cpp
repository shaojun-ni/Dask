#include <boost/python.hpp>
#include <boost/python/numpy.hpp>
#include <iostream>
#include <fstream>

#include <SeismicFilters/TypeBuffer.H>
#include <SeismicFilters/2ndMoment.H>

#include <DAGAttributes/ZeroCrossing.h>
#include <DAGBase/ByteDataCube.h>
#include <DAGBase/DataTypes.h>
#include <DAGBase/Point.h>

using namespace boost::python;
using namespace DAG::Attributes;
using namespace DAG::Base;
using namespace VSF;
using namespace std;

namespace np = boost::python::numpy;

void ArrayDataToTypeBuffer(uint8* data, TypeBuffer<uint8>& buffer, int sizex, int sizey, int sizez)
{
	DAG::Base::Point point(sizex, sizey, sizez);
	DAG::Base::ByteDataCube cube(point, data, ORDER_KJI);

	for(unsigned int k = 0; k < sizez; k++)
		for(unsigned int j = 0; j < sizey; j++)
			for(unsigned int i = 0; i < sizex; i++)
				buffer.set(i, j, k, cube.get<uint8>(i, j, k));

	buffer.alignToBorder(true);
}

void TypeBufferToByteCube(TypeBuffer<uint8>& buffer, ByteDataCube& cube)
{
	int sizex = buffer.sizeX();
	int sizey = buffer.sizeY();
	int sizez = buffer.sizeZ();
	const Point point(sizex, sizey, sizez);
	bool alignedToBorder = buffer.isAlignedToBorder();

	cube.resize( point );
	buffer.alignToBorder(true);

	// Copy the data to the output buffer.
	for(uint32 k = 0; k < point.k; k++)
		for(uint32 j = 0; j < point.j; j++)
			for(uint32 i = 0; i < point.i; i++)
				cube.set(i, j, k, buffer.get(i, j, k));

	buffer.alignToBorder(alignedToBorder);

        int numEle = cube.getNumElements();
        int sizeBytes = cube.getSizeInBytes();

        cout << "cube num elements: " << cube.getNumElements() << endl;
        cout << "cube size in bytes: " << cube.getSizeInBytes() << endl;

        uint8* bytePtr = cube.getContents();
        std::vector<uint8> v = vector<uint8>(bytePtr, bytePtr + cube.getNumElements());
}

np::ndarray run(const numpy::ndarray& bytes, int sizex, int sizey, int sizez, int fsx, int fsy, int fsz)
{
	if (sizex * sizey *sizez == 0)
	{
		Py_intptr_t shape[1] = { sizex*sizey*sizez };
		return np::zeros(1, shape, np::dtype::get_builtin<uint8>());
	}
	
   uint8* inBuffer = reinterpret_cast<uint8*>(bytes.get_data());
	DataOrdering order = ORDER_ZYX;
	TypeBuffer<uint8> srcBrick(sizex, sizey, sizez, fsx, fsy, fsz, order);
	ArrayDataToTypeBuffer(inBuffer, srcBrick, sizex, sizey, sizez);

	TypeBuffer<uint8> dstBrick(sizex, sizey, sizez, fsx, fsy, fsz, order);
	TypeBuffer<double> workBrick1(sizex, sizey, sizez, fsx, fsy, fsz, order);
	TypeBuffer<double> workBrick2(sizex, sizey, sizez, fsx, fsy, fsz, order);

	const double zeroCrossing = ZeroCrossing<uint8>::zeroCrossing(0.0);
	double notUsed1 =  DBL_MAX;
	double notUsed2 = -DBL_MAX;
	SecondMoment SecondMomentObj(SEMBLANCE, fsx, fsy, fsz, zeroCrossing, true, notUsed1, notUsed2);
																																					
	SecondMomentObj.run(srcBrick,
							workBrick1,
							workBrick2, 
							dstBrick,
							true, false,
							false, false,
							false, false);

	ByteDataCube cube(ORDER_KJI);
	TypeBufferToByteCube(dstBrick, cube);

	uint8* data = cube.getContents();
	Py_intptr_t shape[1] = { sizex*sizey*sizez };
	np::ndarray result = np::zeros(1, shape, np::dtype::get_builtin<uint8>());
	std::copy(data, data + sizex*sizey*sizez, reinterpret_cast<uint8*>(result.get_data()));
	return result;
}

BOOST_PYTHON_MODULE(semblance_wrap)
{
	boost::python::numpy::initialize();
	def("run", run);
}
