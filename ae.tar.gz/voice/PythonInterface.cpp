#include <boost/python/numpy.hpp>

#include "ComplexWrap.hpp"
#include "FaultHighWrap.hpp"
#include "SemblanceWrap.hpp"
#include "SharpSemblanceWrap.hpp"

BOOST_PYTHON_MODULE(voice_wrap)
{
	boost::python::numpy::initialize();
	def("sharp_semblance_run", sharp_semblance_run);
	def("semblance_run", semblance_run);
	def("complex_trace_run", complex_trace_run);
	def("fault_high_run", fault_high_run);
}


