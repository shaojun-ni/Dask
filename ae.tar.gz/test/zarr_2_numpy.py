import os
import sys
import numpy as np
import zarr
import os

def convert2numpy(zarrfile, outputpath):

    numpyarray = zarr.open(zarrfile, mode='r')

    print('dttype = ' + numpyarray.dtype)
    np.save(outputpath, numpyarray)

    return


def main(argv):
    if len(argv) < 2:
        print('Usage:python zarr_2_numpy.py <input_zarr_file> <output_numpy_path>')

    print('args:{0}'.format(argv))

    convert2numpy(argv[0], argv[1])


if __name__ == "__main__":
    main(sys.argv[1:])