python test_compute.py ../data/brazil.vt /glb/data/CDIS5/users/ussnis/attribute_engine/dataOut/final 'Semblance,Envelope,Instantaneous'
