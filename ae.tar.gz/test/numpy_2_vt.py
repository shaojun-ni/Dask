
import numpy as np
import sys
import os
from geoio.geoio import GeoIoVolume


def numpy_2_vt(numpy_file, vt_file, original_path):
    # get original volume header
    print('Read original file header')
    filepath = os.path.basename(numpy_file)
    original_name = os.path.splitext(filepath)[0] + '.vt'
    existing_vt_filename = original_path + '/' + original_name
    existing_volume = GeoIoVolume(existing_vt_filename)
    header, check = existing_volume.get_header_info()

    print('Load data from numpy')
    npdata = np.load(numpy_file)

    # Create new volume
    vt = GeoIoVolume(vt_file, header, check)

    print('Create new vt file.')
    vt.put(npdata)


def main(argv):
    if len(argv) < 3:
        print('Usage:python numpy_2_vt.py <numpy_file> <vt_path> <original_vt_path>')
        exit(1)

    print('args:{0}'.format(argv))

    numpy_2_vt(argv[0], argv[1], argv[2])
    print('done!')
    return


if __name__ == "__main__":
    main(sys.argv[1:])
