import sys
import attengineshell as attE



def main(argv):
    if len(argv) < 3:
        print('Usage:python zarr_2_vt.py <zarr_file> <vt_file> <original vt path>')
        exit(1)

    print('args:{0}'.format(argv))

    attE.FileConverter.zarr_2_vt(zarr_file=argv[0], vt_file=argv[1], original_path=argv[2])

    print('done!')


if __name__ == "__main__":
    main(sys.argv[1:])