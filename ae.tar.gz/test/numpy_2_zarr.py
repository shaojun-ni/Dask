
import os
import sys
import numpy as np
import zarr

def convertToZarr(numpyfile, outputpath, x_size, y_size, z_size, usecompressor):
    print('start converting {0} ...'.format(numpyfile))
    filepath = os.path.basename(numpyfile)
    npdata = np.load(numpyfile)
    print('input data size = {0}, data shape = {1}, data type = {2}'.format(npdata.size, npdata.shape, npdata.dtype))

    name = os.path.splitext(filepath)[0]
    item = outputpath + '/' + name
    store = zarr.DirectoryStore(item)
    group = zarr.hierarchy.group(store=store, overwrite=True, synchronizer=zarr.ThreadSynchronizer())

    the_var = name + '.zarr'
    if not usecompressor:
        out_zarr = group.zeros(the_var, shape=npdata.shape, dtype=npdata.dtype, compressor=None, chunks=[x_size, y_size, z_size])
    else:
        out_zarr = group.zeros(the_var, shape=npdata.shape, dtype=npdata.dtype, chunks=[x_size, y_size, z_size])

    out_zarr[...] = npdata[...]
    return

def main(argv):
    if len(argv) < 5:
        print('Usage:python numpy_2_zarr.py <inputfile> <output_path> <x_size> <y_size>. <z_size>')

    print('args:{0}'.format(argv))

    usecompressor = False
    if len(argv) == 6 and argv[5] == 'True':
        usecompressor = True

    filepath = argv[0]

    convertToZarr(filepath, argv[1], argv[2], argv[3], argv[4], usecompressor)
    print('done!')
    return


if __name__ == "__main__":
    main(sys.argv[1:])

#numpyfile = '/glb/data/cdis_projects/users/ussnis/attEngine6/data/F3_seis.npy'
#numpyfile = '/glb/data/cdis_projects/users/ussnis/attEngine6/data/seis_fourpoint.npy'
#print('start converting {0} ...'.format(numpyfile))

#npdata = np.load(numpyfile)


#print('input data size = {0}, data shape = {1}, data type = {2}'.format(npdata.size, npdata.shape, npdata.dtype))

#item = '../data_zarr/F3_seis'
#item = '../data_zarr/seis_fourpoint'

#store = zarr.DirectoryStore(item)
#group = zarr.hierarchy.group(store=store, overwrite=True, synchronizer=zarr.ThreadSynchronizer())
#the_var = 'F3_seis.zarr'
#the_var = 'seis_fourpoint.zarr'
#out_zarr = group.zeros(the_var, shape=npdata.shape, dtype=npdata.dtype, chunks=[500, 500, 500])
#out_zarr[...] = npdata[...]
#print('zarr compressor = {0}'.format(out_zarr.compressor))


