
import numpy as np
import sys
import geoio.geoio as geoio


def convertVT2Numpy(vt_file, numpy_file):
    volume = geoio.GeoIoVolume(vt_file)
    header, check = volume.get_header_info()
    daa = volume.get_float((0,0,0,), (1,1,1))
    narray = np.array(volume.get_float())
    np.save(numpy_file, narray)


def main(argv):
    if len(argv) < 2:
        print('Usage:python vt_2_numpy.py <input_vt_file> <output_numpy_path>')

    print('args:{0}'.format(argv))

    convertVT2Numpy(argv[0], argv[1])


if __name__ == "__main__":
    main(sys.argv[1:])