import sys
import attengineshell as attE


def main(argv):
    if len(argv) < 5:
        print('Usage:pytho vt_2_zarr.py <vt_file> <zarr_file> <x_size> <y_size>. <z_size>')
        exit(1)

    print('args:{0}'.format(argv))

    usecompressor = False
    if len(argv) == 6 and argv[5] == 'True':
        usecompressor = True

    attE.FileConverter.vt_2_zarr(argv[0], argv[1], argv[2], argv[3], argv[4], usecompressor)

    print('done!')


if __name__ == "__main__":
    main(sys.argv[1:])