# from dask_scheduler import DASKScheduler as ds
import sys
import time
import attengineshell as ate

def main(argv):
    if len(argv) < 4:
        print('Usage:python start_ae.py <scheduler_ip> <scheduler port> <boken_port> <workers_file>')
        exit(1)

    print('args:{0}'.format(argv))

    with open(argv[3]) as f:
        my_lines = f.readlines()

    print(my_lines)
    sch = ate.DASKScheduler(argv[0], argv[1], argv[2], my_lines)

    sch.start()

    boken_ip = sch.get_boken()
    print(boken_ip)

    time.sleep(5)

    sch.start_workers()
    time.sleep(30)

    input("Enter any key to quit: ")
    print('quit!')

    sch.stop_scheduler()


if __name__ == "__main__":
    main(sys.argv[1:])
