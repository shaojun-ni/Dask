from dask.distributed import Client, progress, wait
import attengineshell as ate
# import numpy as np
# import dask.array as da
# import dask
import sys
import os
import shutil

sys.path.insert(0, '../thirdparty/singleTrace_d2geo/')
# import CompleTrace as cmpAttr
# from semblance import semblance


def main(argv):
    if len(argv) < 4:
        print('Usage:python compute_attributes.py <scheduler addr> <input_file_path> <output_dir> <zarr_path>')
        exit(1)

    print('scheduler addr:' + argv[0])
    print('input file:' + argv[1])
    print('output file:' + argv[2])
    print('zarr path:' + argv[3])

    filepath = os.path.basename(argv[1])
    name = os.path.splitext(filepath)[0]
    zarr_path = argv[3]

    client = Client(address=argv[0], set_as_default=True, name='client_test', direct_to_workers=True)
    output_dir = '{0}/{1}'.format(argv[2], name)
    print('outputDir:' + output_dir)

    if not os.path.exists(output_dir):
        os.mkdir(output_dir)
    else:
        shutil.rmtree(output_dir)
        os.mkdir(output_dir)

    ### convert .vt to .zarr
    print('Convert vt to zarr file...')
    ate.FileConverter.vt_2_zarr(argv[1], zarr_path, 300, 300, 300, False)
    zarr_file = '{0}/{1}/{1}.zarr'.format(zarr_path, name)

    semblance_out_file_zarr = '{0}/{1}_semblance.zarr'.format(output_dir, name)
    print('semblance_out_file_zarr:' + semblance_out_file_zarr)
    semblance = ate.Semblance()
    semblance.set_params(client, zarr_file, semblance_out_file_zarr, False)
    data_in, res_semblance = semblance.run()

    del res_semblance

    singletrace_outfile_zarr = '{0}/{1}_singletrace_envelope.zarr'.format(output_dir, name)
    print('singletrace_envelope_out_file_zarr:' + singletrace_outfile_zarr)
    envelope = ate.SingleTrace.Envelope()
    envelope.set_params(client, data_in, singletrace_outfile_zarr, False)
    data_in, res_enevl = envelope.run_new()

    del res_enevl

    singletrace_instantaneous_outfile_zarr = '{0}/{1}_singletrace_instantaneous.zarr'.format(output_dir, name)
    print('singletrace_envelope_out_file_zarr:' + singletrace_instantaneous_outfile_zarr)
    instaphase = ate.SingleTrace.Envelope()
    instaphase.set_params(client, data_in, singletrace_instantaneous_outfile_zarr, False)
    data_in, res_instaphase = instaphase.run_new()

    del res_instaphase
    del data_in

    print('convert zarr files to vts...')
    semblance_vt_file = '{0}/{1}_semblance.vt'.format(output_dir, name)
    #origin_vt_fmt_file = '{0}/data_zarr/{1}/{1}.vt'.format(general_path, name)
    print('semblance_vt_file:' + semblance_vt_file)
    if os.path.exists(semblance_vt_file):
        os.remove(semblance_vt_file)

    print('Input file is:' + semblance_out_file_zarr)
    ate.FileConverter.zarr_2_vt(zarr_file=semblance_out_file_zarr, vt_file=semblance_vt_file,
                                original_path=argv[1])

    singletrace_envelope_vt = '{0}/{1}_singletrace_envelope.vt'.format(output_dir, name)
    print('singletrace_envelope_vt_file:' + singletrace_envelope_vt)
    if os.path.exists(singletrace_envelope_vt):
        os.remove(singletrace_envelope_vt)

    print('Input file is:' + singletrace_instantaneous_outfile_zarr)
    ate.FileConverter.zarr_2_vt(zarr_file=singletrace_instantaneous_outfile_zarr, vt_file=singletrace_envelope_vt,
                                original_path=argv[1])

    singletrace_instantaneous_vt = '{0}/{1}_singletrace_instantaneous.vt'.format(output_dir, name)
    print('singletrace_instantaneous_vt_file:' + singletrace_instantaneous_vt)
    if os.path.exists(singletrace_instantaneous_vt):
        os.remove(singletrace_instantaneous_vt)

    print('Input file is:' + singletrace_instantaneous_outfile_zarr)
    ate.FileConverter.zarr_2_vt(zarr_file=singletrace_instantaneous_outfile_zarr, vt_file=singletrace_instantaneous_vt,
                                original_path=argv[1])


if __name__ == "__main__":
    main(sys.argv[1:])