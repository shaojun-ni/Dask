python compute_attributes.py tcp://10.53.2.146:8788 ../data/seismic.vt ../dataOut ../data_zarr
