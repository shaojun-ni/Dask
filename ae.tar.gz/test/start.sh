python start_ae.py 10.53.2.146 8788 8789 worker_nodes.txt
