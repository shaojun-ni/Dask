import sys
import attengineshell as attE



def main(argv):
    if len(argv) < 2:
        print('Usage:python zarr_2_numpyfile.py <zarr_file> <numpy_file>')
        exit(1)

    print('args:{0}'.format(argv))

    attE.FileConverter.zarr_2_numpyfile(zarrfile=argv[0], outputpath=argv[1])

    print('done!')


if __name__ == "__main__":
    main(sys.argv[1:])