import attengineshell as ate
import sys


def main(argv):
    if len(argv) < 7:
        print('Usage:python create_zarrs_from_vt__by_bins.py <vt_file> <out_path> <number_of_files> <overlap> <size_x> <size_y> <size_z>')
        exit(1)

    print('args:{0}'.format(argv))

    ate.FileConverter.vt_2_zarrs_by_bin(argv[0], argv[1], int(argv[2]), int(argv[3]), int(argv[4]), int(argv[5]), int(argv[6]))

    print('done!')
    return


if __name__ == "__main__":
    main(sys.argv[1:])