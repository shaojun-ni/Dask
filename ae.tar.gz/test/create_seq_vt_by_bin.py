import os
import argparse
import numpy as np
import sys
from geoio.geoio import GeoIoVolume, FileMode_update
#from scipy.signal import hilbert
from scipy.signal import hilbert



def main(argv):
    if len(argv) != 3:
        print('Usage: python create_seq_vt_by_bin.py <input file> <output file prefix> <number of bins>')
        exit(1)

    intercept = GeoIoVolume(argv[0])
    header, check = intercept.get_header_info()

    #i_data = intercept.get_float()
    #print(i_data.shape)

    print(check.num_tracks)
    print(check.num_bins)
    print(check.num_samples)

    output = (argv[1])
    #new_vt = GeoIoVolume(output_filename, header, check)
    #new_vt.put(chi_angle_seismic)

    #### Loop over Bins
    step = int(argv[2])
    indices = [x for x in range(0, check.num_bins, step)]
    print(indices)

    count = 0
    for index in indices:
        output_filename = '{0}_{1}.vt'.format(output, count)
        print('output file_name:' + output_filename)
        slice_1 = (index, 0, 0)

        if index+step > check.num_bins-1:
            slice_2 = (check.num_bins-1, check.num_tracks-1, check.num_samples-1)
            check.num_bins = check.num_bins - index - 1
        else:
            slice_2 = (index+step, check.num_tracks-1, check.num_samples-1)
            check.num_bins = step

        new_vt = GeoIoVolume(output_filename, header, check)

        input_data = intercept.get_byte(slice_1, slice_2)

        new_vt.put(input_data) #, slice_1, slice_2)
        print(input_data.shape)
        count += 1

    print('done!')


if __name__ == "__main__":
    main(sys.argv[1:])
	 
