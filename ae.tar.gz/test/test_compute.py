import sys
import attengineshell as ate
import cProfile as profile
import ast
from dask_jobqueue import LSFCluster
import time
from dask.distributed import progress


def main(argv):
    if len(argv) < 3:
        print('Usage:python test_compute.py <input_vt_file> <output_path> <attributes> <configfile_path> <parameters>')
        exit(1)

    print('args:{0}'.format(argv))

    # c = test_setup_nodes()
    # test_c(c)
    # test_c(c)

    # pr = profile.Profile()
    # pr.enable()
    test_compute_class(argv)

    # pr.dump_stats('profile.pstat')


def slow_inc(x):
    time.sleep(1)
    return x + 1


def test_setup_nodes():
    cluster = LSFCluster(queue='default.q', project='att_eng', walltime='80:00', cores=24, processes=24, memory='100GB',
                         dashboard_address=':8790')
    cluster.scale(72)
    from dask.distributed import Client
    client = Client(cluster)
    return client


def test_c(client):
    futures = client.map(slow_inc, range(100))
    progress(futures)


def test_compute_class(argv):
    # semblance = {"win_x": 1, "win_y": 1, "win_z": 4}
    # parameters = {"Semblance": semblance}
    # print(parameters)

    # meta = ate.ComputeMetaData(argv[3])
    # print(meta.get_parameters())
    # print(meta.get_attributes())

    if len(argv) == 5:
        param = ast.literal_eval(argv[4])
        c = ate.Compute(argv[0], argv[1], argv[2], configfile=argv[3], parameters=param)
    elif len(argv) == 4:
        if ".yaml" in argv[3]:
            c = ate.Compute(argv[0], argv[1], argv[2], configfile=argv[3])
        else:
            param = ast.literal_eval(argv[3])
            c = ate.Compute(argv[0], argv[1], argv[2], parameters=param)
    else:
        c = ate.Compute(argv[0], argv[1], argv[2])

    # split vt, don't skip zarr conversion
    #c.start(split_vt=True, skip_2_zarr=False)
    # c.start(split_vt=False, skip_2_zarr=False, use_hpc = True)
    # split, skip zarr conversion.
    # c.start(True, True)
    # don't split, don't skip zarr conversion
    c.start(False, False, True)
    # c.start(False, False)
    # don't split, skip zarr conversion
    #c.start(False, True, False)


if __name__ == "__main__":
    main(sys.argv[1:])
