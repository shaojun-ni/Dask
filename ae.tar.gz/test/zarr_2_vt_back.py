import numpy as np
import sys
import os
import zarr
from geoio.geoio import GeoIoVolume, SpVerticalTraceHeaderArray, SpVerticalTraceCheckArray


def createTempHeader()->(SpVerticalTraceHeaderArray, SpVerticalTraceCheckArray):
    header = SpVerticalTraceHeaderArray()
    header.bits_per_sample = 8
    header.min_clip_amp = -1000
    header.max_clip_amp = 1000
    header.inline_crossline = ord('I')
    header.track_direction = ord('D')
    header.bin_direction = ord('A')
    check = SpVerticalTraceCheckArray()
    check.track_dir = ord('V')
    check.num_tracks = 10
    check.num_bins = 20
    check.num_samples = 30

    return header, check

def numpyarray_2_vt(numpy_array, vt_file, numpy_file, original_path):
    print('Read original file header')

    tempheader, tempcheck = createTempHeader()
    tempcheck.num_tracks = int(numpy_array.shape[0])
    tempcheck.num_bins = int(numpy_array.shape[1])
    tempcheck.num_samples = int(numpy_array.shape[2])

    if original_path:
        filepath = os.path.basename(numpy_file)
        original_name = os.path.splitext(filepath)[0] + '.vt'
        existing_vt_filename = original_path + '/' + original_name
        print('vt header file name:' + existing_vt_filename)
        if os.path.exists(existing_vt_filename):
            existing_volume = GeoIoVolume(existing_vt_filename)
            header, check = existing_volume.get_header_info()
            # Create new volume
            vt = GeoIoVolume(vt_file, header, check)
        else:
            vt = GeoIoVolume(vt_file, tempheader, tempcheck)
    else:
        vt = GeoIoVolume(vt_file, tempheader, tempcheck)

    print('Create new vt file.')
    vt.put(numpy_array)


def numpyfile_2_vt(numpy_file, vt_file, original_path):
    print('Load data from numpy')
    npdata = np.load(numpy_file)
    numpyarray_2_vt(npdata, numpy_file, vt_file, original_path)


def convert_zarr_2_numpy(zarrfile):
    numpyarray = zarr.open(zarrfile, mode='r')
    return np.array(numpyarray)


def zarr_2_vt(zarr_file, vt_file, original_path):
    numpy_array = convert_zarr_2_numpy(zarr_file)
    numpyarray_2_vt(numpy_array, vt_file, zarr_file, original_path)


def main(argv):
    if len(argv) < 3:
        print('Usage:python zarr_2_vt.py <numpy_file> <vt_path> <original_vt_path>')
        exit(1)

    print('args:{0}'.format(argv))

    zarr_2_vt(argv[0], argv[1], argv[2])
    print('done!')
    return


if __name__ == "__main__":
    main(sys.argv[1:])