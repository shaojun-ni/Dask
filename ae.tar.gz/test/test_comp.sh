python test_compute.py ../data/seismic.vt ../dataOut/final "SharpSemblance" compute.yaml "{'SharpSemblance':{'win_x': 3, 'win_y': 3, 'win_z': 11}}"
