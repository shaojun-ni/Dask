python test_compute.py ../data/fourpoint.vt ../dataOut/final "Envelope,Semblance" compute.yaml "{'Semblance':{'win_x': 1, 'win_y': 1, 'win_z': 4},'xyz':{'param1':2, 'param2':3}}"
