This is the original Dask and Jupyter Notebook code base from Nicolas.Below is the setup steps.




			Dask and Jupyter Notebook Environment Setup Instructions for Attribute Engine
	
Setup Python Virtual Environment:

1.	Login to linux k dev machine, i.e. houcy1-n-cp101k26

2.	Create scripts directory in the dev machine�s home directory and Copy loadve.sh and setupve.sh to this directory.

3.	Create attEngine directory under /glb/data/cdis_projects/users/ussnis
	Ussnis is my linux account name, you should have your own.
	Create directories python-env and python-pip under directory attEngine.

4.	In both sh files, replace user name Ussnis with your own user name.

5.	Run source setupve to install python 3.5.1.

6.	Run source loadve.sh to setup python virtual environment.

7.	Upgrade pip to the latest version using the following command
	pip install --proxy=https://proxy-eu.shell.com:8080 --upgrade pip

8.	Install juypter to the virtual environment
	pip3 install --proxy=https://proxy-eu.shell.com:8080 jupyter

9.	Downgrade tornado to 5.1.1  (Jupyter installer puts the latest tornado, which does not work well with Python 3.5.1. We have to use tornado 5.1.1.)
	pip uninstall --proxy=https://proxy-eu.shell.com:8080 tornado
	pip install --proxy=https://proxy-eu.shell.com:8080 tornado===5.1.1

Setup DASK

10.	Copy packages from Nicolas env to your Python virtual environment
	cp -r /glb/data/cdis_projects/users/usnrej/attEngine/python-env/lib/python3.5/site-packages/ .

11.	Copy Dask executables from Nicolas env to your Python virtual environment
	cp  /glb/data/cdis_projects/users/usnrej/attEngine/python-env/bin/dask* .

12.	Use command ifconfig to find out the ip address of the current dev machine.

13.	Launch Jupyter Notebook using the following command
	Jupyter Notebook --ip xx.xxx.xxx.xxx

14.	Copy the URL of the Jupyter Notebook from the console and access it from any browser.

Create CDIS Nodes

15.	Define environment variables for creating project and node group

	export InstallDir=/glb/data/cdis_projects/projects/nightly/current                                           
	-- User nightly build to create project and node group
	export DataSetDir=/glb/data/CDIS5/users/usxlia/CDIS/data/Mars-4D                                      
	-- Use data set in this directory to create project.  Modify it if necessary
	export PATH=${InstallDir}/bin:$PATH                                                                                                 
	-- Set PATH for executables
	export cdisUser=usxlia                                                                                                                            
	-- Set user name.  Change it to your own linux user
              export cdisProject=${cdisUser}-Mars-4D                                                                                            
	-- Set CDIS project name. Modify it if necessary
	export myGroup=nightly_${cdisProject}                                                                                            
	-- Set node group name

16.	Create the CDIS project with a vt file using the following command.
	cdis-launcher mkproject --cdis_user ${cdisUser} --cdis_project ${cdisProject}  --multvt_filename ${DataSetDir}/Mars_Basic_5D_testing_obn2007_baseline_corrected.vt

17.	Create a cluster group with 2 nodes using the following command.
	cdis-launcher parman start-group -g ${myGroup} -n 2 -c cdisdev-compute-nodes -p ${cdisProject} --cdis_user ${cdisUser}

18.	Load data into cluster group using the following commands:
	cdis-launcher parman list-tracesets -p ${cdisProject} -o ${cdisUser} 
	-- use this to check the -t value for the next command
	cdis-launcher parman load-traceset -g ${myGroup} -t 5ba243ac37e12c108d6c4fe3 (Mars_Basic_5D_testing_obn2007_baseline)         --force --verbose                           
	-- load it to cluster memory
19.	Check the log file to get the ip addresse list of the created group nodes.

Setup Attribute Engine

20.	Copy notebook directory from Nicolas env to your Python virtual environment
	cp -r /glb/data/cdis_projects/users/usnrej/attEngine/notebooks/ .

21.	Copy module directory from Nicolas env to your Python virtual environment
	cp -r /glb/data/cdis_projects/users/usnrej/attEngine/module/ .

22.	Modify file scheduler.py in folder /glb/data/cdis_projects/users/usxlia/attEngine/module/att/attengineshell of your own directory
	Change self.scheduler_command to 
	'/glb/data/cdis_projects/users/usxlia/attEngine/python-evn/bin/dask-scheduler'
	Change self.worker_command to 
	'/glb/data/cdis_projects/users/usxlia/attEngine/python-evn/bin/dask-worker'
	Change setuppythonNew.sh to loadve.sh

23.	From Jupyter Notebook web page, open startScheduler.ipynb under notebook. Change the workers host ip addresses to the ip addresses you created in the node group and found from the 	log file.  Run this file to create Dask scheduler and workers.

24.	Run Dask Diagnosis page to check the status of scheduler and workers.

25.	Open file client_2.ipynb under notebook to run tasks to computer attributes and visualize results.                                                                                                                                                            
